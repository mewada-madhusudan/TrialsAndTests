import pytest
import json
import sqlite3
import tempfile
import os
from datetime import datetime, date
from unittest.mock import patch

import sys

sys.path.insert(0, '/workspace/uploads')


# Test basic database functionality
class TestDatabaseBasics:
    """Basic database tests"""

    @pytest.mark.unit
    def test_sqlite_connection(self):
        """Test basic SQLite connection"""
        # Create temporary database
        db_fd, db_path = tempfile.mkstemp(suffix='.db')
        os.close(db_fd)

        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("CREATE TABLE test (id INTEGER PRIMARY KEY, name TEXT)")
            cursor.execute("INSERT INTO test (name) VALUES (?)", ("test_name",))
            conn.commit()

            cursor.execute("SELECT * FROM test")
            result = cursor.fetchone()
            assert result[1] == "test_name"

            conn.close()
        finally:
            os.unlink(db_path)

    @pytest.mark.unit
    def test_database_import(self):
        """Test that we can import database modules"""
        try:
            from database import DatabaseManager, get_db_connection, init_database
            assert DatabaseManager is not None
            assert get_db_connection is not None
            assert init_database is not None
        except ImportError:
            pytest.skip("Database module not available")

    @pytest.mark.unit
    def test_schema_import(self):
        """Test that we can import schema modules"""
        try:
            from schemas import RoleDelegationCreate, CardholderDataUpdate
            assert RoleDelegationCreate is not None
            assert CardholderDataUpdate is not None
        except ImportError:
            pytest.skip("Schema module not available")


class TestDatabaseOperations:
    """Test database operations if modules are available"""

    @pytest.mark.unit
    def test_database_manager_methods_exist(self):
        """Test that DatabaseManager has expected methods"""
        try:
            from database import DatabaseManager

            # Check that required methods exist
            assert hasattr(DatabaseManager, 'create_role_delegation')
            assert hasattr(DatabaseManager, 'get_role_delegations')
            assert hasattr(DatabaseManager, 'create_cardholder_record')
            assert hasattr(DatabaseManager, 'get_cardholder_records')
            assert hasattr(DatabaseManager, 'update_cardholder_record')
            assert hasattr(DatabaseManager, 'get_status_counts')

        except ImportError:
            pytest.skip("Database module not available")

    @pytest.mark.unit
    def test_database_initialization(self):
        """Test database initialization"""
        try:
            from database import init_database

            # Create temporary database
            db_fd, db_path = tempfile.mkstemp(suffix='.db')
            os.close(db_fd)

            try:
                with patch('database.DATABASE_URL', db_path):
                    init_database()

                # Check that tables were created
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = [row[0] for row in cursor.fetchall()]

                expected_tables = ['role_delegations', 'data_uploads', 'cardholder_data']
                for table in expected_tables:
                    assert table in tables, f"Table {table} not found"

                conn.close()
            finally:
                os.unlink(db_path)

        except ImportError:
            pytest.skip("Database module not available")


class TestSchemaValidation:
    """Test schema validation if modules are available"""

    @pytest.mark.unit
    def test_role_delegation_schema(self):
        """Test role delegation schema validation"""
        try:
            from schemas import RoleDelegationCreate

            # Test valid data
            valid_data = {
                "delegator_sid": "EMP001",
                "delegate_sid": "EMP002",
                "role_id": "CERTIFIER",
                "effective_from": date(2024, 1, 1),
                "effective_to": date(2024, 12, 31)
            }

            delegation = RoleDelegationCreate(**valid_data)
            assert delegation.delegator_sid == "EMP001"
            assert delegation.is_active is True  # Default value

        except ImportError:
            pytest.skip("Schema module not available")

    @pytest.mark.unit
    def test_cardholder_update_schema(self):
        """Test cardholder update schema validation"""
        try:
            from schemas import CardholderDataUpdate

            # Test valid data
            valid_data = {
                "record_id": "rec-123",
                "employee_name": "Test Name",
                "team": "Test Team"
            }

            update = CardholderDataUpdate(**valid_data)
            assert update.record_id == "rec-123"
            assert update.employee_name == "Test Name"

        except ImportError:
            pytest.skip("Schema module not available")