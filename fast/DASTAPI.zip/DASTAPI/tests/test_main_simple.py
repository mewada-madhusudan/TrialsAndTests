import pytest
import os
import tempfile
from datetime import date
from unittest.mock import patch, mock_open
from fastapi import status, FastAPI, HTTPException, UploadFile, File, Query
from fastapi.testclient import TestClient
from fastapi.responses import FileResponse
from typing import List, Optional, Dict
from io import BytesIO
import pandas as pd
import json
import uuid

import sys

sys.path.insert(0, '/workspace/uploads')

from database import DatabaseManager
from schemas import RoleDelegationCreate, CardholderDataUpdate

# Create a simplified version of the main app for testing
app = FastAPI(title="Test Cardholder Management API", version="1.0.0")


@app.get("/")
async def root():
    return {"message": "Cardholder Management API", "version": "1.0.0"}


@app.get("/records")
async def fetch_records(
        quarter_id: Optional[str] = Query(None),
        certifier_id: Optional[str] = Query(None),
        status: Optional[str] = Query(None),
        limit: int = Query(100, le=1000),
        offset: int = Query(0),
):
    """Fetch records from cardholder_data table"""
    try:
        records = DatabaseManager.get_cardholder_records(
            quarter_id=quarter_id,
            certifier_id=certifier_id,
            status=status,
            limit=limit,
            offset=offset
        )
        return records
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching records: {str(e)}")


@app.post("/save-records")
async def save_records(
        records: List[CardholderDataUpdate],
        updated_by: str = Query(...),
):
    """Save modified records back to database"""
    try:
        updated_count = 0
        for record_update in records:
            update_data = record_update.dict(exclude_unset=True)
            record_id = update_data.pop('record_id')

            if DatabaseManager.update_cardholder_record(record_id, update_data, updated_by):
                updated_count += 1

        return {"message": f"Successfully updated {updated_count} records"}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error saving records: {str(e)}")


@app.get("/delegates")
async def fetch_delegates(
        is_active: Optional[bool] = Query(None),
        role_id: Optional[str] = Query(None),
):
    """Fetch records from role_delegations table"""
    try:
        delegations = DatabaseManager.get_role_delegations(
            is_active=is_active,
            role_id=role_id
        )
        return delegations
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching delegates: {str(e)}")


@app.post("/make-delegate")
async def make_delegate(delegation: RoleDelegationCreate):
    """Create a new role delegation record"""
    try:
        delegation_data = delegation.dict()
        delegation_id = DatabaseManager.create_role_delegation(delegation_data)

        # Return the created delegation
        delegations = DatabaseManager.get_role_delegations()
        created_delegation = next((d for d in delegations if d['delegation_id'] == delegation_id), None)

        return created_delegation

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating delegation: {str(e)}")


@app.get("/status")
async def get_status_counts(quarter_id: Optional[str] = Query(None)):
    """Get count of different statuses"""
    try:
        status_counts = DatabaseManager.get_status_counts(quarter_id=quarter_id)
        return status_counts

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting status counts: {str(e)}")


class TestRootEndpoint:
    """Test root endpoint"""

    @pytest.mark.integration
    def test_root_endpoint(self, client):
        """Test root endpoint returns correct response"""
        response = client.get("/")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["message"] == "Cardholder Management API"
        assert data["version"] == "1.0.0"


class TestFetchRecordsEndpoint:
    """Test fetch records endpoint"""

    @pytest.mark.integration
    def test_fetch_records_no_filters(self, db_manager, sample_cardholder_data):
        """Test fetching records without filters"""
        # Create test data
        db_manager.create_cardholder_record(sample_cardholder_data)

        with patch('database.DATABASE_URL', '/tmp/test.db'):
            client = TestClient(app)
            response = client.get("/records")
            assert response.status_code == status.HTTP_200_OK
            data = response.json()
            assert isinstance(data, list)

    @pytest.mark.integration
    def test_fetch_records_with_quarter_filter(self, db_manager, sample_cardholder_data):
        """Test fetching records with quarter filter"""
        # Create test data
        db_manager.create_cardholder_record(sample_cardholder_data)

        with patch('database.DATABASE_URL', '/tmp/test.db'):
            client = TestClient(app)
            response = client.get("/records?quarter_id=Q1_2024")
            assert response.status_code == status.HTTP_200_OK
            data = response.json()
            assert isinstance(data, list)

    @pytest.mark.integration
    def test_fetch_records_limit_validation(self):
        """Test fetch records with invalid limit"""
        client = TestClient(app)
        response = client.get("/records?limit=2000")  # Exceeds max limit of 1000
        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY


class TestSaveRecordsEndpoint:
    """Test save records endpoint"""

    @pytest.mark.integration
    def test_save_records_success(self, db_manager, sample_cardholder_data):
        """Test successful record saving"""
        # Create test record
        record_id = db_manager.create_cardholder_record(sample_cardholder_data)

        # Update data
        update_data = [{
            "record_id": record_id,
            "employee_name": "Updated Name",
            "process_owner_status": "approved"
        }]

        with patch('database.DATABASE_URL', '/tmp/test.db'):
            client = TestClient(app)
            response = client.post(
                "/save-records?updated_by=test_updater",
                json=update_data
            )

            assert response.status_code == status.HTTP_200_OK
            data = response.json()
            assert "Successfully updated" in data["message"]

    @pytest.mark.integration
    def test_save_records_missing_updated_by(self):
        """Test save records without updated_by parameter"""
        update_data = [{
            "record_id": "test-id",
            "employee_name": "Updated Name"
        }]

        client = TestClient(app)
        response = client.post("/save-records", json=update_data)
        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY


class TestFetchDelegatesEndpoint:
    """Test fetch delegates endpoint"""

    @pytest.mark.integration
    def test_fetch_delegates_no_filters(self, db_manager, sample_delegation_data):
        """Test fetching delegates without filters"""
        # Create test delegation
        db_manager.create_role_delegation(sample_delegation_data)

        with patch('database.DATABASE_URL', '/tmp/test.db'):
            client = TestClient(app)
            response = client.get("/delegates")
            assert response.status_code == status.HTTP_200_OK
            data = response.json()
            assert isinstance(data, list)


class TestMakeDelegateEndpoint:
    """Test make delegate endpoint"""

    @pytest.mark.integration
    def test_make_delegate_success(self, sample_delegation_data):
        """Test successful delegate creation"""
        client = TestClient(app)
        response = client.post("/make-delegate", json=sample_delegation_data)

        # Should either succeed or fail gracefully
        assert response.status_code in [status.HTTP_200_OK, status.HTTP_500_INTERNAL_SERVER_ERROR]

    @pytest.mark.integration
    def test_make_delegate_invalid_data(self):
        """Test delegate creation with invalid data"""
        invalid_data = {
            "delegator_sid": "EMP001"
            # Missing required fields
        }

        client = TestClient(app)
        response = client.post("/make-delegate", json=invalid_data)
        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY


class TestGetStatusEndpoint:
    """Test get status endpoint"""

    @pytest.mark.integration
    def test_get_status_counts_success(self, db_manager, sample_cardholder_data):
        """Test successful status counts retrieval"""
        # Create test data
        db_manager.create_cardholder_record(sample_cardholder_data)

        with patch('database.DATABASE_URL', '/tmp/test.db'):
            client = TestClient(app)
            response = client.get("/status")
            assert response.status_code == status.HTTP_200_OK
            data = response.json()

            assert "process_owner" in data
            assert "area_owner" in data
            assert "certifier" in data