import pytest
import json
from datetime import datetime, date
from unittest.mock import patch

import sys

sys.path.append('/workspace/uploads')

from database import DatabaseManager, get_db_connection


class TestDatabaseManager:
    """Unit tests for DatabaseManager class"""

    @pytest.mark.unit
    def test_create_role_delegation(self, db_manager, sample_delegation_data):
        """Test creating a role delegation"""
        delegation_id = db_manager.create_role_delegation(sample_delegation_data)

        assert delegation_id is not None
        assert isinstance(delegation_id, str)

        # Verify delegation was created
        delegations = db_manager.get_role_delegations()
        assert len(delegations) == 1
        assert delegations[0]['delegation_id'] == delegation_id
        assert delegations[0]['delegator_sid'] == sample_delegation_data['delegator_sid']

    @pytest.mark.unit
    def test_get_role_delegations_with_filters(self, db_manager, sample_delegation_data):
        """Test fetching role delegations with filters"""
        # Create test delegation
        delegation_id = db_manager.create_role_delegation(sample_delegation_data)

        # Test filter by is_active
        active_delegations = db_manager.get_role_delegations(is_active=True)
        assert len(active_delegations) == 1

        inactive_delegations = db_manager.get_role_delegations(is_active=False)
        assert len(inactive_delegations) == 0

        # Test filter by role_id
        role_delegations = db_manager.get_role_delegations(role_id="CERTIFIER")
        assert len(role_delegations) == 1

        other_role_delegations = db_manager.get_role_delegations(role_id="OTHER")
        assert len(other_role_delegations) == 0

    @pytest.mark.unit
    def test_create_data_upload(self, db_manager, sample_upload_data):
        """Test creating a data upload record"""
        upload_id = db_manager.create_data_upload(sample_upload_data)

        assert upload_id is not None
        assert isinstance(upload_id, str)

    @pytest.mark.unit
    def test_update_upload_status(self, db_manager, sample_upload_data):
        """Test updating upload status"""
        upload_id = db_manager.create_data_upload(sample_upload_data)

        # Update status
        db_manager.update_upload_status(upload_id, "completed", 15)

        # Verify update (we would need to add a get method to verify this)
        # For now, we just ensure no exception is raised
        assert True

    @pytest.mark.unit
    def test_create_cardholder_record(self, db_manager, sample_cardholder_data):
        """Test creating a cardholder record"""
        record_id = db_manager.create_cardholder_record(sample_cardholder_data)

        assert record_id is not None
        assert isinstance(record_id, str)

        # Verify record was created
        records = db_manager.get_cardholder_records()
        assert len(records) == 1
        assert records[0]['record_id'] == record_id
        assert records[0]['certifier_id'] == sample_cardholder_data['certifier_id']

    @pytest.mark.unit
    def test_get_cardholder_records_with_filters(self, db_manager, sample_cardholder_data):
        """Test fetching cardholder records with filters"""
        # Create test record
        record_id = db_manager.create_cardholder_record(sample_cardholder_data)

        # Test filter by quarter_id
        quarter_records = db_manager.get_cardholder_records(quarter_id="Q1_2024")
        assert len(quarter_records) == 1

        other_quarter_records = db_manager.get_cardholder_records(quarter_id="Q2_2024")
        assert len(other_quarter_records) == 0

        # Test filter by certifier_id
        certifier_records = db_manager.get_cardholder_records(certifier_id="CERT001")
        assert len(certifier_records) == 1

        # Test pagination
        paginated_records = db_manager.get_cardholder_records(limit=1, offset=0)
        assert len(paginated_records) == 1

        empty_page = db_manager.get_cardholder_records(limit=1, offset=1)
        assert len(empty_page) == 0

    @pytest.mark.unit
    def test_update_cardholder_record(self, db_manager, sample_cardholder_data):
        """Test updating a cardholder record"""
        # Create test record
        record_id = db_manager.create_cardholder_record(sample_cardholder_data)

        # Update data
        update_data = {
            "employee_name": "Updated Name",
            "team": "Updated Team",
            "process_owner_status": "approved"
        }

        result = db_manager.update_cardholder_record(record_id, update_data, "test_updater")
        assert result is True

        # Verify update
        records = db_manager.get_cardholder_records()
        updated_record = records[0]
        assert updated_record['employee_name'] == "Updated Name"
        assert updated_record['team'] == "Updated Team"
        assert updated_record['process_owner_status'] == "approved"

        # Verify history was updated
        history = json.loads(updated_record['history'])
        assert len(history) == 2  # Original creation + update
        assert history[1]['action'] == 'updated'
        assert history[1]['user'] == 'test_updater'

    @pytest.mark.unit
    def test_update_cardholder_record_no_changes(self, db_manager, sample_cardholder_data):
        """Test updating a cardholder record with no actual changes"""
        # Create test record
        record_id = db_manager.create_cardholder_record(sample_cardholder_data)

        # Try to update with same data
        update_data = {
            "employee_name": sample_cardholder_data["employee_name"]
        }

        result = db_manager.update_cardholder_record(record_id, update_data, "test_updater")
        assert result is False  # No changes made

    @pytest.mark.unit
    def test_get_records_for_report(self, db_manager, sample_cardholder_data):
        """Test getting records for report generation"""
        # Create test record
        record_id = db_manager.create_cardholder_record(sample_cardholder_data)

        # Test date range filter
        start_date = date.today()
        end_date = date.today()

        records = db_manager.get_records_for_report(start_date, end_date)
        assert len(records) == 1

        # Test with filters
        records_with_quarter = db_manager.get_records_for_report(
            start_date, end_date, quarter_id="Q1_2024"
        )
        assert len(records_with_quarter) == 1

        records_wrong_quarter = db_manager.get_records_for_report(
            start_date, end_date, quarter_id="Q2_2024"
        )
        assert len(records_wrong_quarter) == 0

    @pytest.mark.unit
    def test_get_status_counts(self, db_manager, sample_cardholder_data):
        """Test getting status counts"""
        # Create test records with different statuses
        record1_data = sample_cardholder_data.copy()
        record1_data['process_owner_status'] = 'approved'
        record1_data['area_owner_status'] = 'pending_confirmation'
        record1_data['certifier_status'] = 'pending_review'

        record2_data = sample_cardholder_data.copy()
        record2_data['certifier_id'] = 'CERT002'
        record2_data['process_owner_status'] = 'rejected'
        record2_data['area_owner_status'] = 'approved'
        record2_data['certifier_status'] = 'approved'

        db_manager.create_cardholder_record(record1_data)
        db_manager.create_cardholder_record(record2_data)

        status_counts = db_manager.get_status_counts()

        assert 'process_owner' in status_counts
        assert 'area_owner' in status_counts
        assert 'certifier' in status_counts

        assert status_counts['process_owner']['approved'] == 1
        assert status_counts['process_owner']['rejected'] == 1
        assert status_counts['area_owner']['pending_confirmation'] == 1
        assert status_counts['area_owner']['approved'] == 1
        assert status_counts['certifier']['pending_review'] == 1
        assert status_counts['certifier']['approved'] == 1

    @pytest.mark.unit
    def test_get_status_counts_with_quarter_filter(self, db_manager, sample_cardholder_data):
        """Test getting status counts with quarter filter"""
        # Create test record
        db_manager.create_cardholder_record(sample_cardholder_data)

        # Test with matching quarter
        status_counts = db_manager.get_status_counts(quarter_id="Q1_2024")
        assert status_counts['process_owner']['pending_review'] == 1

        # Test with non-matching quarter
        status_counts_empty = db_manager.get_status_counts(quarter_id="Q2_2024")
        assert len(status_counts_empty['process_owner']) == 0
        assert len(status_counts_empty['area_owner']) == 0
        assert len(status_counts_empty['certifier']) == 0


class TestDatabaseConnection:
    """Test database connection functionality"""

    @pytest.mark.unit
    def test_get_db_connection(self, test_db):
        """Test database connection context manager"""
        with patch('database.DATABASE_URL', test_db):
            with get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = cursor.fetchall()

                # Verify expected tables exist
                table_names = [table[0] for table in tables]
                assert 'role_delegations' in table_names
                assert 'data_uploads' in table_names
                assert 'cardholder_data' in table_names