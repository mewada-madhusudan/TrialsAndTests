import pytest
import json
import sqlite3
import tempfile
import os
from datetime import datetime, date
from unittest.mock import patch, MagicMock
from fastapi.testclient import TestClient
from fastapi import FastAPI, HTTPException, Query
from typing import List, Optional
import pandas as pd
from io import BytesIO

import sys

sys.path.insert(0, '/workspace/uploads')

# Create a test FastAPI app
app = FastAPI(title="Test Cardholder Management API", version="1.0.0")


@app.get("/")
async def root():
    return {"message": "Cardholder Management API", "version": "1.0.0"}


class TestComprehensiveAPI:
    """Comprehensive API tests"""

    @pytest.mark.integration
    def test_api_root_endpoint(self):
        """Test the root endpoint"""
        client = TestClient(app)
        response = client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert data["message"] == "Cardholder Management API"
        assert data["version"] == "1.0.0"


class TestDatabaseComprehensive:
    """Comprehensive database tests"""

    @pytest.mark.unit
    def test_database_table_creation(self):
        """Test that all required tables are created"""
        try:
            from database import init_database

            # Create temporary database
            db_fd, db_path = tempfile.mkstemp(suffix='.db')
            os.close(db_fd)

            try:
                with patch('database.DATABASE_URL', db_path):
                    init_database()

                # Verify tables exist
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()

                # Check role_delegations table
                cursor.execute("PRAGMA table_info(role_delegations)")
                columns = [col[1] for col in cursor.fetchall()]
                expected_columns = ['delegation_id', 'delegator_sid', 'delegate_sid', 'role_id', 'effective_from',
                                    'effective_to', 'is_active', 'created_at']
                for col in expected_columns:
                    assert col in columns, f"Column {col} not found in role_delegations"

                # Check cardholder_data table
                cursor.execute("PRAGMA table_info(cardholder_data)")
                columns = [col[1] for col in cursor.fetchall()]
                expected_columns = ['record_id', 'upload_id', 'quarter_id', 'certifier_id', 'employee_name',
                                    'process_owner_status']
                for col in expected_columns:
                    assert col in columns, f"Column {col} not found in cardholder_data"

                # Check data_uploads table
                cursor.execute("PRAGMA table_info(data_uploads)")
                columns = [col[1] for col in cursor.fetchall()]
                expected_columns = ['upload_id', 'quarter_id', 'uploaded_by', 'file_name', 'upload_status']
                for col in expected_columns:
                    assert col in columns, f"Column {col} not found in data_uploads"

                conn.close()
            finally:
                os.unlink(db_path)

        except ImportError:
            pytest.skip("Database module not available")

    @pytest.mark.unit
    def test_database_crud_operations(self):
        """Test basic CRUD operations"""
        try:
            from database import DatabaseManager, init_database

            # Create temporary database
            db_fd, db_path = tempfile.mkstemp(suffix='.db')
            os.close(db_fd)

            try:
                with patch('database.DATABASE_URL', db_path):
                    init_database()

                    # Test role delegation creation
                    delegation_data = {
                        "delegator_sid": "EMP001",
                        "delegate_sid": "EMP002",
                        "role_id": "CERTIFIER",
                        "effective_from": date(2024, 1, 1),
                        "effective_to": date(2024, 12, 31),
                        "is_active": True
                    }

                    delegation_id = DatabaseManager.create_role_delegation(delegation_data)
                    assert delegation_id is not None

                    # Test fetching delegations
                    delegations = DatabaseManager.get_role_delegations()
                    assert len(delegations) >= 1

                    # Test cardholder record creation
                    cardholder_data = {
                        "upload_id": "test-upload",
                        "quarter_id": "Q1_2024",
                        "certifier_id": "CERT001",
                        "employee_name": "Test Employee",
                        "history": json.dumps(
                            [{"action": "created", "timestamp": datetime.now().isoformat(), "user": "test"}])
                    }

                    record_id = DatabaseManager.create_cardholder_record(cardholder_data)
                    assert record_id is not None

                    # Test fetching records
                    records = DatabaseManager.get_cardholder_records()
                    assert len(records) >= 1

            finally:
                os.unlink(db_path)

        except ImportError:
            pytest.skip("Database module not available")


class TestSchemaValidationComprehensive:
    """Comprehensive schema validation tests"""

    @pytest.mark.unit
    def test_pydantic_models_exist(self):
        """Test that Pydantic models can be imported and instantiated"""
        try:
            from schemas import RoleDelegationCreate, CardholderDataUpdate, StatusResponse, ReportRequest

            # Test RoleDelegationCreate
            delegation = RoleDelegationCreate(
                delegator_sid="EMP001",
                delegate_sid="EMP002",
                role_id="CERTIFIER",
                effective_from=date(2024, 1, 1),
                effective_to=date(2024, 12, 31)
            )
            assert delegation.delegator_sid == "EMP001"
            assert delegation.is_active is True

            # Test CardholderDataUpdate
            update = CardholderDataUpdate(
                record_id="rec-123",
                employee_name="Updated Name"
            )
            assert update.record_id == "rec-123"
            assert update.employee_name == "Updated Name"

            # Test StatusResponse
            status = StatusResponse(
                process_owner={"approved": 5},
                area_owner={"pending": 3},
                certifier={"rejected": 1}
            )
            assert status.process_owner["approved"] == 5

            # Test ReportRequest
            report = ReportRequest(
                start_date=date(2024, 1, 1),
                end_date=date(2024, 12, 31)
            )
            assert report.start_date == date(2024, 1, 1)

        except ImportError:
            pytest.skip("Schema module not available")


class TestFileOperations:
    """Test file operations and Excel handling"""

    @pytest.mark.unit
    def test_excel_file_creation(self):
        """Test creating Excel files with pandas"""
        # Create sample data
        data = {
            'certifier_id': ['CERT001', 'CERT002'],
            'employee_name': ['John Doe', 'Jane Smith'],
            'team': ['Finance', 'HR'],
            'status': ['approved', 'pending']
        }

        df = pd.DataFrame(data)

        # Create Excel file in memory
        excel_buffer = BytesIO()
        df.to_excel(excel_buffer, index=False)
        excel_buffer.seek(0)

        # Verify file was created
        assert len(excel_buffer.getvalue()) > 0

        # Read it back
        excel_buffer.seek(0)
        df_read = pd.read_excel(excel_buffer)
        assert len(df_read) == 2
        assert 'certifier_id' in df_read.columns
        assert df_read.iloc[0]['employee_name'] == 'John Doe'

    @pytest.mark.unit
    def test_json_operations(self):
        """Test JSON serialization/deserialization"""
        # Test history tracking
        history = [
            {
                "action": "created",
                "timestamp": datetime.now().isoformat(),
                "user": "test_user"
            },
            {
                "action": "updated",
                "timestamp": datetime.now().isoformat(),
                "user": "test_updater",
                "changes": {"status": {"old": "pending", "new": "approved"}}
            }
        ]

        # Serialize to JSON
        history_json = json.dumps(history)
        assert isinstance(history_json, str)

        # Deserialize from JSON
        history_parsed = json.loads(history_json)
        assert len(history_parsed) == 2
        assert history_parsed[0]["action"] == "created"
        assert history_parsed[1]["changes"]["status"]["new"] == "approved"


class TestErrorHandling:
    """Test error handling scenarios"""

    @pytest.mark.unit
    def test_database_connection_error_handling(self):
        """Test handling of database connection errors"""
        try:
            from database import get_db_connection

            # Test with invalid database path
            with patch('database.DATABASE_URL', '/invalid/path/database.db'):
                try:
                    with get_db_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute("SELECT 1")
                except Exception as e:
                    # Should handle the error gracefully
                    assert isinstance(e, Exception)

        except ImportError:
            pytest.skip("Database module not available")

    @pytest.mark.unit
    def test_invalid_data_handling(self):
        """Test handling of invalid data"""
        try:
            from schemas import RoleDelegationCreate
            from pydantic import ValidationError

            # Test with missing required fields
            with pytest.raises(ValidationError):
                RoleDelegationCreate(
                    delegator_sid="EMP001"
                    # Missing required fields
                )

            # Test with invalid date
            with pytest.raises(ValidationError):
                RoleDelegationCreate(
                    delegator_sid="EMP001",
                    delegate_sid="EMP002",
                    role_id="CERTIFIER",
                    effective_from="invalid_date",
                    effective_to="invalid_date"
                )

        except ImportError:
            pytest.skip("Schema module not available")


class TestBusinessLogic:
    """Test business logic and workflows"""

    @pytest.mark.integration
    def test_complete_workflow_simulation(self):
        """Test a complete workflow from upload to report"""
        try:
            from database import DatabaseManager, init_database

            # Create temporary database
            db_fd, db_path = tempfile.mkstemp(suffix='.db')
            os.close(db_fd)

            try:
                with patch('database.DATABASE_URL', db_path):
                    init_database()

                    # Step 1: Create upload record
                    upload_data = {
                        "quarter_id": "Q1_2024",
                        "uploaded_by": "test_user",
                        "file_name": "test_data.xlsx",
                        "file_path": "/tmp/test_data.xlsx",
                        "file_size": 1024,
                        "upload_status": "processing",
                        "records_count": 2
                    }
                    upload_id = DatabaseManager.create_data_upload(upload_data)
                    assert upload_id is not None

                    # Step 2: Create cardholder records
                    for i in range(2):
                        cardholder_data = {
                            "upload_id": upload_id,
                            "quarter_id": "Q1_2024",
                            "certifier_id": f"CERT{i:03d}",
                            "employee_name": f"Employee {i}",
                            "process_owner_status": "pending_review",
                            "area_owner_status": "pending_confirmation",
                            "certifier_status": "pending_review",
                            "history": json.dumps([{
                                "action": "created",
                                "timestamp": datetime.now().isoformat(),
                                "user": "test_user"
                            }])
                        }
                        record_id = DatabaseManager.create_cardholder_record(cardholder_data)
                        assert record_id is not None

                    # Step 3: Update upload status
                    DatabaseManager.update_upload_status(upload_id, "completed", 2)

                    # Step 4: Fetch and verify records
                    records = DatabaseManager.get_cardholder_records(quarter_id="Q1_2024")
                    assert len(records) == 2

                    # Step 5: Update a record
                    record_to_update = records[0]
                    update_data = {
                        "process_owner_status": "approved",
                        "process_owner_comment": "Approved by test"
                    }
                    result = DatabaseManager.update_cardholder_record(
                        record_to_update['record_id'],
                        update_data,
                        "test_approver"
                    )
                    assert result is True

                    # Step 6: Get status counts
                    status_counts = DatabaseManager.get_status_counts(quarter_id="Q1_2024")
                    assert "process_owner" in status_counts
                    assert status_counts["process_owner"]["approved"] >= 1
                    assert status_counts["process_owner"]["pending_review"] >= 1

                    # Step 7: Create role delegation
                    delegation_data = {
                        "delegator_sid": "CERT000",
                        "delegate_sid": "CERT001",
                        "role_id": "CERTIFIER",
                        "effective_from": date(2024, 1, 1),
                        "effective_to": date(2024, 12, 31),
                        "is_active": True
                    }
                    delegation_id = DatabaseManager.create_role_delegation(delegation_data)
                    assert delegation_id is not None

                    # Step 8: Verify delegation
                    delegations = DatabaseManager.get_role_delegations(is_active=True)
                    assert len(delegations) >= 1

            finally:
                os.unlink(db_path)

        except ImportError:
            pytest.skip("Database module not available")


class TestPerformanceAndScalability:
    """Test performance and scalability aspects"""

    @pytest.mark.unit
    def test_large_dataset_handling(self):
        """Test handling of larger datasets"""
        # Create a larger dataset
        data = {
            'certifier_id': [f'CERT{i:03d}' for i in range(100)],
            'employee_name': [f'Employee {i}' for i in range(100)],
            'team': [f'Team {i % 10}' for i in range(100)],
            'status': ['approved' if i % 2 == 0 else 'pending' for i in range(100)]
        }

        df = pd.DataFrame(data)
        assert len(df) == 100

        # Test filtering
        approved = df[df['status'] == 'approved']
        assert len(approved) == 50

        # Test grouping
        by_team = df.groupby('team').size()
        assert len(by_team) == 10

    @pytest.mark.unit
    def test_pagination_logic(self):
        """Test pagination logic"""
        # Simulate pagination parameters
        total_records = 250
        page_size = 50

        # Calculate pages
        total_pages = (total_records + page_size - 1) // page_size
        assert total_pages == 5

        # Test offset calculation
        for page in range(1, total_pages + 1):
            offset = (page - 1) * page_size
            limit = page_size

            # Simulate fetching records
            start_record = offset + 1
            end_record = min(offset + limit, total_records)

            assert start_record <= end_record
            assert end_record <= total_records