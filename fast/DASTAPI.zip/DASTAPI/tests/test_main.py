import pytest
import os
import tempfile
from datetime import date
from unittest.mock import patch, mock_open
from fastapi import status
from io import BytesIO

import sys

sys.path.append('/workspace/uploads')


class TestRootEndpoint:
    """Test root endpoint"""

    @pytest.mark.integration
    def test_root_endpoint(self, client):
        """Test root endpoint returns correct response"""
        response = client.get("/")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["message"] == "Cardholder Management API"
        assert data["version"] == "1.0.0"


class TestUploadExcelEndpoint:
    """Test upload Excel endpoint"""

    @pytest.mark.integration
    def test_upload_excel_success(self, client, sample_excel_file, cleanup_files):
        """Test successful Excel file upload"""
        # Create temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp_file:
            tmp_file.write(sample_excel_file.getvalue())
            tmp_file_path = tmp_file.name
            cleanup_files.append(tmp_file_path)

        with open(tmp_file_path, 'rb') as f:
            response = client.post(
                "/upload-excel?quarter_id=Q1_2024&uploaded_by=test_user",
                files={
                    "file": ("test_data.xlsx", f, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
            )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "message" in data
        assert "upload_id" in data
        assert "records_processed" in data
        assert "total_rows" in data
        assert data["records_processed"] > 0

    @pytest.mark.integration
    def test_upload_excel_invalid_file_type(self, client):
        """Test upload with invalid file type"""
        # Create a text file instead of Excel
        file_content = b"This is not an Excel file"

        response = client.post(
            "/upload-excel?quarter_id=Q1_2024&uploaded_by=test_user",
            files={"file": ("test_data.txt", BytesIO(file_content), "text/plain")}
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        data = response.json()
        assert "Only Excel files are allowed" in data["detail"]

    @pytest.mark.integration
    def test_upload_excel_missing_parameters(self, client, sample_excel_file):
        """Test upload without required parameters"""
        response = client.post(
            "/upload-excel",  # Missing quarter_id and uploaded_by
            files={"file": ("test_data.xlsx", sample_excel_file,
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
        )

        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY


class TestFetchRecordsEndpoint:
    """Test fetch records endpoint"""

    @pytest.mark.integration
    def test_fetch_records_no_filters(self, client, db_manager, sample_cardholder_data):
        """Test fetching records without filters"""
        # Create test data
        db_manager.create_cardholder_record(sample_cardholder_data)

        response = client.get("/records")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1

    @pytest.mark.integration
    def test_fetch_records_with_quarter_filter(self, client, db_manager, sample_cardholder_data):
        """Test fetching records with quarter filter"""
        # Create test data
        db_manager.create_cardholder_record(sample_cardholder_data)

        response = client.get("/records?quarter_id=Q1_2024")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1

        # Test with non-existent quarter
        response = client.get("/records?quarter_id=Q2_2024")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert len(data) == 0

    @pytest.mark.integration
    def test_fetch_records_with_pagination(self, client, db_manager, sample_cardholder_data):
        """Test fetching records with pagination"""
        # Create multiple test records
        for i in range(5):
            record_data = sample_cardholder_data.copy()
            record_data['certifier_id'] = f'CERT{i:03d}'
            db_manager.create_cardholder_record(record_data)

        # Test limit
        response = client.get("/records?limit=2")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert len(data) == 2

        # Test offset
        response = client.get("/records?limit=2&offset=2")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert len(data) == 2

    @pytest.mark.integration
    def test_fetch_records_limit_validation(self, client):
        """Test fetch records with invalid limit"""
        response = client.get("/records?limit=2000")  # Exceeds max limit of 1000
        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY


class TestSaveRecordsEndpoint:
    """Test save records endpoint"""

    @pytest.mark.integration
    def test_save_records_success(self, client, db_manager, sample_cardholder_data):
        """Test successful record saving"""
        # Create test record
        record_id = db_manager.create_cardholder_record(sample_cardholder_data)

        # Update data
        update_data = [{
            "record_id": record_id,
            "employee_name": "Updated Name",
            "process_owner_status": "approved"
        }]

        response = client.post(
            "/save-records?updated_by=test_updater",
            json=update_data
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "Successfully updated 1 records" in data["message"]

    @pytest.mark.integration
    def test_save_records_missing_updated_by(self, client):
        """Test save records without updated_by parameter"""
        update_data = [{
            "record_id": "test-id",
            "employee_name": "Updated Name"
        }]

        response = client.post("/save-records", json=update_data)
        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    @pytest.mark.integration
    def test_save_records_empty_list(self, client):
        """Test save records with empty list"""
        response = client.post(
            "/save-records?updated_by=test_updater",
            json=[]
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "Successfully updated 0 records" in data["message"]


class TestFetchDelegatesEndpoint:
    """Test fetch delegates endpoint"""

    @pytest.mark.integration
    def test_fetch_delegates_no_filters(self, client, db_manager, sample_delegation_data):
        """Test fetching delegates without filters"""
        # Create test delegation
        db_manager.create_role_delegation(sample_delegation_data)

        response = client.get("/delegates")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1

    @pytest.mark.integration
    def test_fetch_delegates_with_filters(self, client, db_manager, sample_delegation_data):
        """Test fetching delegates with filters"""
        # Create test delegation
        db_manager.create_role_delegation(sample_delegation_data)

        # Test is_active filter
        response = client.get("/delegates?is_active=true")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert len(data) >= 1

        # Test role_id filter
        response = client.get("/delegates?role_id=CERTIFIER")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert len(data) >= 1


class TestMakeDelegateEndpoint:
    """Test make delegate endpoint"""

    @pytest.mark.integration
    def test_make_delegate_success(self, client, sample_delegation_data):
        """Test successful delegate creation"""
        response = client.post("/make-delegate", json=sample_delegation_data)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "delegation_id" in data
        assert data["delegator_sid"] == sample_delegation_data["delegator_sid"]
        assert data["delegate_sid"] == sample_delegation_data["delegate_sid"]

    @pytest.mark.integration
    def test_make_delegate_invalid_data(self, client):
        """Test delegate creation with invalid data"""
        invalid_data = {
            "delegator_sid": "EMP001"
            # Missing required fields
        }

        response = client.post("/make-delegate", json=invalid_data)
        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY


class TestGenerateReportEndpoint:
    """Test generate report endpoint"""

    @pytest.mark.integration
    def test_generate_report_success(self, client, db_manager, sample_cardholder_data, cleanup_files):
        """Test successful report generation"""
        # Create test data
        db_manager.create_cardholder_record(sample_cardholder_data)

        response = client.get(
            f"/report?start_date={date.today()}&end_date={date.today()}"
        )

        assert response.status_code == status.HTTP_200_OK
        assert response.headers["content-type"] == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

        # Check that file was created (cleanup will be handled by fixture)
        assert len(response.content) > 0

    @pytest.mark.integration
    def test_generate_report_with_filters(self, client, db_manager, sample_cardholder_data):
        """Test report generation with filters"""
        # Create test data
        db_manager.create_cardholder_record(sample_cardholder_data)

        response = client.get(
            f"/report?start_date={date.today()}&end_date={date.today()}&quarter_id=Q1_2024&certifier_id=CERT001"
        )

        assert response.status_code == status.HTTP_200_OK
        assert len(response.content) > 0

    @pytest.mark.integration
    def test_generate_report_missing_dates(self, client):
        """Test report generation without required dates"""
        response = client.get("/report")
        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    @pytest.mark.integration
    def test_generate_report_invalid_date_format(self, client):
        """Test report generation with invalid date format"""
        response = client.get("/report?start_date=invalid&end_date=invalid")
        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY


class TestGetStatusEndpoint:
    """Test get status endpoint"""

    @pytest.mark.integration
    def test_get_status_counts_success(self, client, db_manager, sample_cardholder_data):
        """Test successful status counts retrieval"""
        # Create test data with different statuses
        record1_data = sample_cardholder_data.copy()
        record1_data['process_owner_status'] = 'approved'

        record2_data = sample_cardholder_data.copy()
        record2_data['certifier_id'] = 'CERT002'
        record2_data['process_owner_status'] = 'rejected'

        db_manager.create_cardholder_record(record1_data)
        db_manager.create_cardholder_record(record2_data)

        response = client.get("/status")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()

        assert "process_owner" in data
        assert "area_owner" in data
        assert "certifier" in data
        assert isinstance(data["process_owner"], dict)
        assert isinstance(data["area_owner"], dict)
        assert isinstance(data["certifier"], dict)

    @pytest.mark.integration
    def test_get_status_counts_with_quarter_filter(self, client, db_manager, sample_cardholder_data):
        """Test status counts with quarter filter"""
        # Create test data
        db_manager.create_cardholder_record(sample_cardholder_data)

        response = client.get("/status?quarter_id=Q1_2024")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()

        # Should have at least one record in each status category
        assert len(data["process_owner"]) > 0 or len(data["area_owner"]) > 0 or len(data["certifier"]) > 0

    @pytest.mark.integration
    def test_get_status_counts_empty_database(self, client):
        """Test status counts with empty database"""
        response = client.get("/status")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()

        assert "process_owner" in data
        assert "area_owner" in data
        assert "certifier" in data


class TestErrorHandling:
    """Test error handling across endpoints"""

    @pytest.mark.integration
    def test_database_error_handling(self, client):
        """Test handling of database errors"""
        # This test would require mocking database failures
        # For now, we'll test that the endpoints handle missing records gracefully

        # Try to update non-existent record
        update_data = [{
            "record_id": "non-existent-id",
            "employee_name": "Updated Name"
        }]

        response = client.post(
            "/save-records?updated_by=test_updater",
            json=update_data
        )

        # Should not crash, might return 0 updated records
        assert response.status_code in [status.HTTP_200_OK, status.HTTP_500_INTERNAL_SERVER_ERROR]

    @pytest.mark.integration
    def test_invalid_json_handling(self, client):
        """Test handling of invalid JSON data"""
        response = client.post(
            "/save-records?updated_by=test_updater",
            data="invalid json",
            headers={"Content-Type": "application/json"}
        )

        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY