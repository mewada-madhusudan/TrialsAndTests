import pytest
from datetime import date, datetime
from pydantic import ValidationError

import sys

sys.path.append('/workspace/uploads')

from schemas import (
    RoleDelegationCreate, RoleDelegationResponse,
    CardholderDataResponse, CardholderDataUpdate,
    StatusResponse, ReportRequest
)


class TestRoleDelegationCreate:
    """Test RoleDelegationCreate schema"""

    @pytest.mark.unit
    def test_valid_role_delegation_create(self):
        """Test valid role delegation creation"""
        data = {
            "delegator_sid": "EMP001",
            "delegate_sid": "EMP002",
            "role_id": "CERTIFIER",
            "effective_from": date(2024, 1, 1),
            "effective_to": date(2024, 12, 31)
        }

        delegation = RoleDelegationCreate(**data)
        assert delegation.delegator_sid == "EMP001"
        assert delegation.delegate_sid == "EMP002"
        assert delegation.role_id == "CERTIFIER"
        assert delegation.is_active is True  # Default value

    @pytest.mark.unit
    def test_role_delegation_create_with_is_active_false(self):
        """Test role delegation creation with is_active=False"""
        data = {
            "delegator_sid": "EMP001",
            "delegate_sid": "EMP002",
            "role_id": "CERTIFIER",
            "effective_from": date(2024, 1, 1),
            "effective_to": date(2024, 12, 31),
            "is_active": False
        }

        delegation = RoleDelegationCreate(**data)
        assert delegation.is_active is False

    @pytest.mark.unit
    def test_role_delegation_create_missing_required_fields(self):
        """Test role delegation creation with missing required fields"""
        data = {
            "delegator_sid": "EMP001",
            "delegate_sid": "EMP002"
            # Missing role_id, effective_from, effective_to
        }

        with pytest.raises(ValidationError):
            RoleDelegationCreate(**data)

    @pytest.mark.unit
    def test_role_delegation_create_invalid_date_types(self):
        """Test role delegation creation with invalid date types"""
        data = {
            "delegator_sid": "EMP001",
            "delegate_sid": "EMP002",
            "role_id": "CERTIFIER",
            "effective_from": "invalid_date",
            "effective_to": "invalid_date"
        }

        with pytest.raises(ValidationError):
            RoleDelegationCreate(**data)


class TestRoleDelegationResponse:
    """Test RoleDelegationResponse schema"""

    @pytest.mark.unit
    def test_valid_role_delegation_response(self):
        """Test valid role delegation response"""
        data = {
            "delegation_id": "del-123",
            "delegator_sid": "EMP001",
            "delegate_sid": "EMP002",
            "role_id": "CERTIFIER",
            "effective_from": date(2024, 1, 1),
            "effective_to": date(2024, 12, 31),
            "is_active": True,
            "created_at": datetime(2024, 1, 1, 12, 0, 0)
        }

        response = RoleDelegationResponse(**data)
        assert response.delegation_id == "del-123"
        assert response.is_active is True


class TestCardholderDataUpdate:
    """Test CardholderDataUpdate schema"""

    @pytest.mark.unit
    def test_valid_cardholder_data_update(self):
        """Test valid cardholder data update"""
        data = {
            "record_id": "rec-123",
            "employee_name": "Updated Name",
            "team": "Updated Team",
            "process_owner_status": "approved"
        }

        update = CardholderDataUpdate(**data)
        assert update.record_id == "rec-123"
        assert update.employee_name == "Updated Name"
        assert update.team == "Updated Team"
        assert update.process_owner_status == "approved"

    @pytest.mark.unit
    def test_cardholder_data_update_missing_record_id(self):
        """Test cardholder data update without record_id"""
        data = {
            "employee_name": "Updated Name"
            # Missing record_id
        }

        with pytest.raises(ValidationError):
            CardholderDataUpdate(**data)

    @pytest.mark.unit
    def test_cardholder_data_update_optional_fields(self):
        """Test cardholder data update with only record_id"""
        data = {
            "record_id": "rec-123"
        }

        update = CardholderDataUpdate(**data)
        assert update.record_id == "rec-123"
        assert update.employee_name is None
        assert update.team is None

    @pytest.mark.unit
    def test_cardholder_data_update_boolean_field(self):
        """Test cardholder data update with boolean field"""
        data = {
            "record_id": "rec-123",
            "access_to_area_allowed": True
        }

        update = CardholderDataUpdate(**data)
        assert update.access_to_area_allowed is True

    @pytest.mark.unit
    def test_cardholder_data_update_date_fields(self):
        """Test cardholder data update with date fields"""
        data = {
            "record_id": "rec-123",
            "access_from_date": date(2024, 1, 1),
            "access_to_date": date(2024, 12, 31)
        }

        update = CardholderDataUpdate(**data)
        assert update.access_from_date == date(2024, 1, 1)
        assert update.access_to_date == date(2024, 12, 31)


class TestStatusResponse:
    """Test StatusResponse schema"""

    @pytest.mark.unit
    def test_valid_status_response(self):
        """Test valid status response"""
        data = {
            "process_owner": {"approved": 5, "rejected": 2, "pending_review": 3},
            "area_owner": {"approved": 4, "pending_confirmation": 6},
            "certifier": {"approved": 7, "pending_review": 3}
        }

        response = StatusResponse(**data)
        assert response.process_owner["approved"] == 5
        assert response.area_owner["approved"] == 4
        assert response.certifier["approved"] == 7

    @pytest.mark.unit
    def test_status_response_empty_counts(self):
        """Test status response with empty counts"""
        data = {
            "process_owner": {},
            "area_owner": {},
            "certifier": {}
        }

        response = StatusResponse(**data)
        assert response.process_owner == {}
        assert response.area_owner == {}
        assert response.certifier == {}


class TestReportRequest:
    """Test ReportRequest schema"""

    @pytest.mark.unit
    def test_valid_report_request(self):
        """Test valid report request"""
        data = {
            "start_date": date(2024, 1, 1),
            "end_date": date(2024, 12, 31),
            "quarter_id": "Q1_2024",
            "status_filter": "approved",
            "certifier_id": "CERT001"
        }

        request = ReportRequest(**data)
        assert request.start_date == date(2024, 1, 1)
        assert request.end_date == date(2024, 12, 31)
        assert request.quarter_id == "Q1_2024"
        assert request.status_filter == "approved"
        assert request.certifier_id == "CERT001"

    @pytest.mark.unit
    def test_report_request_required_fields_only(self):
        """Test report request with only required fields"""
        data = {
            "start_date": date(2024, 1, 1),
            "end_date": date(2024, 12, 31)
        }

        request = ReportRequest(**data)
        assert request.start_date == date(2024, 1, 1)
        assert request.end_date == date(2024, 12, 31)
        assert request.quarter_id is None
        assert request.status_filter is None
        assert request.certifier_id is None

    @pytest.mark.unit
    def test_report_request_missing_required_fields(self):
        """Test report request with missing required fields"""
        data = {
            "start_date": date(2024, 1, 1)
            # Missing end_date
        }

        with pytest.raises(ValidationError):
            ReportRequest(**data)

    @pytest.mark.unit
    def test_report_request_invalid_date_types(self):
        """Test report request with invalid date types"""
        data = {
            "start_date": "invalid_date",
            "end_date": "invalid_date"
        }

        with pytest.raises(ValidationError):
            ReportRequest(**data)


class TestCardholderDataResponse:
    """Test CardholderDataResponse schema"""

    @pytest.mark.unit
    def test_valid_cardholder_data_response(self):
        """Test valid cardholder data response"""
        data = {
            "record_id": "rec-123",
            "upload_id": "upload-123",
            "quarter_id": "Q1_2024",
            "certifier_id": "CERT001",
            "process_owner_status": "pending_review",
            "area_owner_status": "pending_confirmation",
            "certifier_status": "pending_review",
            "created_at": datetime(2024, 1, 1, 12, 0, 0),
            "updated_at": datetime(2024, 1, 1, 12, 0, 0)
        }

        response = CardholderDataResponse(**data)
        assert response.record_id == "rec-123"
        assert response.upload_id == "upload-123"
        assert response.quarter_id == "Q1_2024"
        assert response.certifier_id == "CERT001"

    @pytest.mark.unit
    def test_cardholder_data_response_with_optional_fields(self):
        """Test cardholder data response with optional fields"""
        data = {
            "record_id": "rec-123",
            "upload_id": "upload-123",
            "quarter_id": "Q1_2024",
            "certifier_id": "CERT001",
            "area_owner_sid": "AO001",
            "area_owner_name": "John Doe",
            "employee_name": "Jane Smith",
            "access_to_area_allowed": True,
            "process_owner_status": "approved",
            "area_owner_status": "approved",
            "certifier_status": "approved",
            "created_at": datetime(2024, 1, 1, 12, 0, 0),
            "updated_at": datetime(2024, 1, 1, 12, 0, 0),
            "history": {"actions": []}
        }

        response = CardholderDataResponse(**data)
        assert response.area_owner_sid == "AO001"
        assert response.area_owner_name == "John Doe"
        assert response.employee_name == "Jane Smith"
        assert response.access_to_area_allowed is True
        assert response.history == {"actions": []}