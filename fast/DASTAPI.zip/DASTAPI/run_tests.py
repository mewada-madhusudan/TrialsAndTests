#!/usr/bin/env python3
"""
Test runner script for the FastAPI Cardholder Management API

This script runs all tests and generates coverage reports.
"""

import subprocess
import sys
import os


def run_command(command, description):
    """Run a command and handle errors"""
    print(f"\n{'=' * 60}")
    print(f"Running: {description}")
    print(f"Command: {command}")
    print(f"{'=' * 60}")

    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(result.stdout)
        if result.stderr:
            print("STDERR:", result.stderr)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error running {description}:")
        print(f"Return code: {e.returncode}")
        print(f"STDOUT: {e.stdout}")
        print(f"STDERR: {e.stderr}")
        return False


def main():
    """Main test runner function"""
    print("FastAPI Cardholder Management API - Test Suite")
    print("=" * 60)

    # Change to the directory containing the tests
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    # Install test dependencies
    if not run_command("pip install -r requirements.txt", "Installing dependencies"):
        print("Failed to install dependencies")
        return 1

    # Run unit tests
    if not run_command("pytest tests/ -m unit -v", "Running unit tests"):
        print("Unit tests failed")
        return 1

    # Run integration tests
    if not run_command("pytest tests/ -m integration -v", "Running integration tests"):
        print("Integration tests failed")
        return 1

    # Run all tests with coverage
    if not run_command("pytest tests/ -v --cov=. --cov-report=term-missing --cov-report=html",
                       "Running all tests with coverage"):
        print("Coverage tests failed")
        return 1

    print("\n" + "=" * 60)
    print("All tests completed successfully!")
    print("Coverage report generated in htmlcov/index.html")
    print("=" * 60)

    return 0


if __name__ == "__main__":
    sys.exit(main())