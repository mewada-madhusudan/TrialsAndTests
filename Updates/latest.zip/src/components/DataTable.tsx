import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Search, Download, Save, Edit2, Check, X } from 'lucide-react';
import type { AccessRecord } from '@/contexts/DataContext';

interface DataTableProps {
  records: AccessRecord[];
  columns: string[];
  onUpdateRecord: (id: string, updates: Partial<AccessRecord>) => void;
  onExport: (format: 'csv' | 'excel') => void;
  canEdit: boolean;
}

export default function DataTable({ records, columns, onUpdateRecord, onExport, canEdit }: DataTableProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [editingRecord, setEditingRecord] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<{
    status: string;
    comments: string;
  }>({ status: '', comments: '' });

  const filteredRecords = records.filter(record => {
    const matchesSearch = Object.values(record.data).some(value =>
      String(value).toLowerCase().includes(searchTerm.toLowerCase())
    );
    const matchesStatus = statusFilter === 'all' || record.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleEdit = (record: AccessRecord) => {
    setEditingRecord(record.id);
    setEditForm({
      status: record.status,
      comments: record.comments || ''
    });
  };

  const handleSave = (recordId: string) => {
    onUpdateRecord(recordId, {
      status: editForm.status as AccessRecord['status'],
      comments: editForm.comments
    });
    setEditingRecord(null);
  };

  const handleCancel = () => {
    setEditingRecord(null);
    setEditForm({ status: '', comments: '' });
  };

  const displayColumns = ['User_ID', 'Access_Type', 'System', 'Status', 'Comments', 'Actions'];
  const maxDisplayColumns = 8;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Access Records ({filteredRecords.length})</CardTitle>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={() => onExport('csv')}>
              <Download className="w-4 h-4 mr-2" />
              CSV
            </Button>
            <Button variant="outline" size="sm" onClick={() => onExport('excel')}>
              <Download className="w-4 h-4 mr-2" />
              Excel
            </Button>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 flex-1">
            <Search className="w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search records..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="Pending">Pending</SelectItem>
              <SelectItem value="In Review">In Review</SelectItem>
              <SelectItem value="Certified">Certified</SelectItem>
              <SelectItem value="Rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      
      <CardContent>
        {filteredRecords.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No records found. {records.length === 0 ? 'Upload data to get started.' : 'Try adjusting your search or filters.'}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  {displayColumns.slice(0, maxDisplayColumns).map((column) => (
                    <th key={column} className="text-left py-3 px-4 font-medium text-gray-700">
                      {column.replace('_', ' ')}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filteredRecords.map((record) => (
                  <tr key={record.id} className="border-b hover:bg-gray-50">
                    <td className="py-3 px-4">
                      {record.data.User_ID || record.data.user_id || 'N/A'}
                    </td>
                    <td className="py-3 px-4">
                      {record.data.Access_Type || record.data.access_type || 'N/A'}
                    </td>
                    <td className="py-3 px-4">
                      {record.data.System || record.data.system || 'N/A'}
                    </td>
                    <td className="py-3 px-4">
                      {editingRecord === record.id ? (
                        <Select value={editForm.status} onValueChange={(value) => setEditForm(prev => ({ ...prev, status: value }))}>
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Pending">Pending</SelectItem>
                            <SelectItem value="In Review">In Review</SelectItem>
                            <SelectItem value="Certified">Certified</SelectItem>
                            <SelectItem value="Rejected">Rejected</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <Badge variant={
                          record.status === 'Certified' ? 'default' :
                          record.status === 'Rejected' ? 'destructive' :
                          record.status === 'In Review' ? 'secondary' : 'outline'
                        }>
                          {record.status}
                        </Badge>
                      )}
                    </td>
                    <td className="py-3 px-4 max-w-xs">
                      {editingRecord === record.id ? (
                        <Textarea
                          value={editForm.comments}
                          onChange={(e) => setEditForm(prev => ({ ...prev, comments: e.target.value }))}
                          placeholder="Add comments..."
                          className="min-h-[60px]"
                        />
                      ) : (
                        <span className="text-sm text-gray-600 truncate block">
                          {record.comments || 'No comments'}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      {editingRecord === record.id ? (
                        <div className="flex items-center space-x-1">
                          <Button size="sm" onClick={() => handleSave(record.id)}>
                            <Check className="w-4 h-4" />
                          </Button>
                          <Button size="sm" variant="outline" onClick={handleCancel}>
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ) : (
                        canEdit && (
                          <Button size="sm" variant="outline" onClick={() => handleEdit(record)}>
                            <Edit2 className="w-4 h-4" />
                          </Button>
                        )
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}