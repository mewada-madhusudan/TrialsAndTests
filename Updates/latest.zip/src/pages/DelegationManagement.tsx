import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useData } from '@/contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  UserPlus, 
  Check, 
  X, 
  Search,
  Users
} from 'lucide-react';

export default function DelegationManagement() {
  const { user } = useAuth();
  const { delegations, addDelegation, updateDelegation } = useData();
  const navigate = useNavigate();
  
  const [delegateId, setDelegateId] = useState('');
  const [delegateName, setDelegateName] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [message, setMessage] = useState('');

  // Mock users for delegation (in real app, this would come from API)
  const availableUsers = [
    { id: 'C001', name: 'Emily Brown' },
    { id: 'C002', name: 'David Wilson' },
    { id: 'C003', name: 'Lisa Garcia' },
    { id: 'C004', name: 'James Miller' },
  ];

  const canManageDelegations = user?.role === 'Process Owner' || user?.role === 'Area Owner';

  const handleAddDelegation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!delegateId || !delegateName) {
      setMessage('Please enter both SID and name');
      return;
    }

    addDelegation({
      areaOwnerId: user?.id || '',
      delegateId,
      delegateName,
      status: 'Pending'
    });

    setDelegateId('');
    setDelegateName('');
    setMessage('Delegation request sent successfully');
    setTimeout(() => setMessage(''), 3000);
  };

  const handleDelegationAction = (id: string, action: 'Accepted' | 'Rejected') => {
    updateDelegation(id, action);
    setMessage(`Delegation ${action.toLowerCase()} successfully`);
    setTimeout(() => setMessage(''), 3000);
  };

  const filteredDelegations = delegations.filter(delegation =>
    delegation.delegateName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    delegation.delegateId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const myDelegations = delegations.filter(d => d.delegateId === user?.id);
  const sentDelegations = delegations.filter(d => d.areaOwnerId === user?.id);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-16 2xl:px-24">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => navigate('/dashboard')}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
              <h1 className="text-2xl font-bold text-gray-900">Delegation Management</h1>
            </div>
          </div>
        </div>
      </header>

      <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-16 2xl:px-24 py-8">
        {message && (
          <Alert className="mb-6">
            <AlertDescription>{message}</AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Add New Delegation */}
          {canManageDelegations && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <UserPlus className="w-5 h-5 mr-2" />
                  Assign Delegate
                </CardTitle>
                <CardDescription>
                  Assign a delegate to help with certification tasks
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAddDelegation} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="delegateId">Delegate SID</Label>
                    <Input
                      id="delegateId"
                      value={delegateId}
                      onChange={(e) => setDelegateId(e.target.value)}
                      placeholder="Enter delegate SID (e.g., C001)"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="delegateName">Delegate Name</Label>
                    <Input
                      id="delegateName"
                      value={delegateName}
                      onChange={(e) => setDelegateName(e.target.value)}
                      placeholder="Enter delegate name"
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full">
                    Send Delegation Request
                  </Button>
                </form>

                <div className="mt-6">
                  <Label className="text-sm font-medium text-gray-700">Available Users:</Label>
                  <div className="mt-2 space-y-2">
                    {availableUsers.map(user => (
                      <div key={user.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                        <span className="text-sm">{user.name}</span>
                        <Badge variant="outline">{user.id}</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Received Delegations */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="w-5 h-5 mr-2" />
                Received Delegations
              </CardTitle>
              <CardDescription>
                Delegation requests you've received
              </CardDescription>
            </CardHeader>
            <CardContent>
              {myDelegations.length === 0 ? (
                <p className="text-gray-500 text-center py-4">No delegation requests received</p>
              ) : (
                <div className="space-y-3">
                  {myDelegations.map((delegation) => (
                    <div key={delegation.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">Delegation Request</p>
                        <p className="text-sm text-gray-600">
                          From Area Owner • {new Date(delegation.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        {delegation.status === 'Pending' ? (
                          <>
                            <Button
                              size="sm"
                              onClick={() => handleDelegationAction(delegation.id, 'Accepted')}
                            >
                              <Check className="w-4 h-4 mr-1" />
                              Accept
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDelegationAction(delegation.id, 'Rejected')}
                            >
                              <X className="w-4 h-4 mr-1" />
                              Reject
                            </Button>
                          </>
                        ) : (
                          <Badge variant={delegation.status === 'Accepted' ? 'default' : 'destructive'}>
                            {delegation.status}
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* All Delegations Table */}
        <Card className="mt-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>All Delegations</CardTitle>
                <CardDescription>
                  {canManageDelegations ? 'Delegations you\'ve sent and received' : 'Your delegation history'}
                </CardDescription>
              </div>
              <div className="flex items-center space-x-2">
                <Search className="w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search delegations..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-64"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {filteredDelegations.length === 0 ? (
              <p className="text-gray-500 text-center py-8">No delegations found</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4 font-medium text-gray-700">Delegate</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-700">SID</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-700">Status</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-700">Date</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-700">Type</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredDelegations.map((delegation) => (
                      <tr key={delegation.id} className="border-b hover:bg-gray-50">
                        <td className="py-3 px-4">{delegation.delegateName}</td>
                        <td className="py-3 px-4">
                          <Badge variant="outline">{delegation.delegateId}</Badge>
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant={
                            delegation.status === 'Accepted' ? 'default' :
                            delegation.status === 'Rejected' ? 'destructive' : 'secondary'
                          }>
                            {delegation.status}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-gray-600">
                          {new Date(delegation.createdAt).toLocaleDateString()}
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant="outline">
                            {delegation.areaOwnerId === user?.id ? 'Sent' : 'Received'}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}