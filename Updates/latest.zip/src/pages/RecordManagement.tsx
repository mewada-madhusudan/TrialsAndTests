import { useAuth } from '@/contexts/AuthContext';
import { useFilteredData } from '@/contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, FileText, Users, Clock, CheckCircle, XCircle, AlertCircle, Eye } from 'lucide-react';
import ExcelLikeTable from '@/components/ExcelLikeTable';

export default function RecordManagement() {
  const { user } = useAuth();
  const { 
    accessRecords, 
    filteredRecords, 
    columns, 
    updateAccessRecord, 
    updateMultipleRecords,
    getStatusSummary,
    getDynamicColumns 
  } = useFilteredData();
  const navigate = useNavigate();
  
  const statusSummary = getStatusSummary();
  const canEdit = user?.role === 'Certifier' || user?.role === 'Area Owner' || user?.role === 'Process Owner';
  const dynamicColumns = getDynamicColumns();

  const handleExport = (format: 'csv' | 'excel') => {
    const recordsToExport = user?.role === 'Process Owner' ? accessRecords : filteredRecords;
    
    if (recordsToExport.length === 0) {
      alert('No records to export');
      return;
    }

    // Create CSV content with all dynamic columns
    const allColumns = [...dynamicColumns, 'id', 'status', 'comments', 'createdAt', 'updatedAt'];
    const headers = allColumns;
    const csvContent = [
      headers.join(','),
      ...recordsToExport.map(record => 
        allColumns.map(col => {
          let value = '';
          switch (col) {
            case 'id':
              value = record.id;
              break;
            case 'status':
              value = record.status;
              break;
            case 'comments':
              value = record.comments || '';
              break;
            case 'createdAt':
              value = record.createdAt;
              break;
            case 'updatedAt':
              value = record.updatedAt;
              break;
            default:
              value = String(record.data[col] || '');
          }
          return `"${value.replace(/"/g, '""')}"`;
        }).join(',')
      )
    ].join('\n');

    // Create and download file
    const blob = new Blob([csvContent], { type: format === 'csv' ? 'text/csv' : 'application/vnd.ms-excel' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `access_records_${new Date().toISOString().split('T')[0]}.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-16 2xl:px-24">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => navigate('/dashboard')}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
              <h1 className="text-2xl font-bold text-gray-900">Record Management</h1>
              {user?.role === 'Area Owner' && (
                <Badge variant="outline" className="ml-2">
                  <Eye className="w-3 h-3 mr-1" />
                  Filtered by SID: {user.sid}
                </Badge>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline">{user?.role}</Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-16 2xl:px-24 py-8">
        {/* Enhanced Status Summary */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 2xl:grid-cols-8 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <Clock className="w-4 h-4 mr-1" />
                Pending
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{statusSummary.pending}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <Users className="w-4 h-4 mr-1" />
                In Review
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{statusSummary.inReview}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <CheckCircle className="w-4 h-4 mr-1" />
                Certified
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{statusSummary.certified}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <XCircle className="w-4 h-4 mr-1" />
                Rejected
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{statusSummary.rejected}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <AlertCircle className="w-4 h-4 mr-1" />
                Open for Review
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">{statusSummary.openForReview}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <AlertCircle className="w-4 h-4 mr-1" />
                Access Required
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-indigo-600">{statusSummary.accessRequired}</div>
            </CardContent>
          </Card>
        </div>

        {/* Role-based Information */}
        {user?.role === 'Area Owner' && (
          <Card className="mb-6 bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-blue-800 flex items-center">
                <Eye className="w-5 h-5 mr-2" />
                Area Owner View
              </CardTitle>
              <CardDescription className="text-blue-700">
                You are viewing only records where your SID ({user.sid}) matches the "Area Owner SID" column. 
                Showing {filteredRecords.length} of {accessRecords.length} total records.
              </CardDescription>
            </CardHeader>
          </Card>
        )}

        {/* Instructions */}
        {accessRecords.length === 0 && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="w-5 h-5 mr-2" />
                Getting Started
              </CardTitle>
              <CardDescription>
                No access records found. Here's how to get started:
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {user?.role === 'Process Owner' && (
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-sm font-semibold text-blue-600">1</span>
                    </div>
                    <div>
                      <p className="font-medium">Upload Data File</p>
                      <p className="text-sm text-gray-600">Go to Data Upload to import your access certification data</p>
                    </div>
                  </div>
                )}
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                    <span className="text-sm font-semibold text-green-600">2</span>
                  </div>
                  <div>
                    <p className="font-medium">Review Records</p>
                    <p className="text-sm text-gray-600">Once data is uploaded, you can review and certify access records</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                    <span className="text-sm font-semibold text-purple-600">3</span>
                  </div>
                  <div>
                    <p className="font-medium">Export Reports</p>
                    <p className="text-sm text-gray-600">Generate and export certification reports for compliance</p>
                  </div>
                </div>
              </div>
              
              {user?.role === 'Process Owner' && (
                <div className="mt-6">
                  <Button onClick={() => navigate('/upload')}>
                    Upload Data File
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Excel-like Data Table */}
        {(user?.role === 'Process Owner' ? accessRecords.length > 0 : filteredRecords.length > 0) && (
          <ExcelLikeTable
            records={filteredRecords}
            columns={dynamicColumns}
            onUpdateRecord={updateAccessRecord}
            onUpdateMultiple={updateMultipleRecords}
            onExport={handleExport}
            canEdit={canEdit}
          />
        )}

        {/* Role-specific Actions */}
        {(user?.role === 'Process Owner' ? accessRecords.length > 0 : filteredRecords.length > 0) && (
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Available Actions</CardTitle>
              <CardDescription>
                Actions available based on your role: {user?.role}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-3">
                {canEdit && (
                  <>
                    <Badge variant="outline" className="px-3 py-1">
                      ✓ Excel-like Editing
                    </Badge>
                    <Badge variant="outline" className="px-3 py-1">
                      ✓ Multi-cell Selection
                    </Badge>
                    <Badge variant="outline" className="px-3 py-1">
                      ✓ Copy/Paste Operations
                    </Badge>
                    <Badge variant="outline" className="px-3 py-1">
                      ✓ Batch Updates
                    </Badge>
                  </>
                )}
                <Badge variant="outline" className="px-3 py-1">
                  ✓ Export Data
                </Badge>
                <Badge variant="outline" className="px-3 py-1">
                  ✓ Search & Filter
                </Badge>
                <Badge variant="outline" className="px-3 py-1">
                  ✓ Dynamic Columns ({dynamicColumns.length} columns)
                </Badge>
                {user?.role === 'Area Owner' && (
                  <Badge variant="outline" className="px-3 py-1">
                    ✓ SID-filtered View
                  </Badge>
                )}
                {(user?.role === 'Process Owner' || user?.role === 'Area Owner') && (
                  <Badge variant="outline" className="px-3 py-1">
                    ✓ Manage Delegations
                  </Badge>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}