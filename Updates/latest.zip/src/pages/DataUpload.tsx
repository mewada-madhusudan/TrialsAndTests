import { useState, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useData } from '@/contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Upload, 
  FileText, 
  CheckCircle, 
  AlertCircle,
  X
} from 'lucide-react';
import type { AccessRecord } from '@/contexts/DataContext';

export default function DataUpload() {
  const { user } = useAuth();
  const { addAccessRecords, setColumns } = useData();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadResult, setUploadResult] = useState<{
    success: boolean;
    message: string;
    recordsCount?: number;
    columnsCount?: number;
  } | null>(null);

  const canUpload = user?.role === 'Process Owner';

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileUpload(files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileUpload(file);
    }
  };

  const handleFileUpload = async (file: File) => {
    if (!canUpload) {
      setUploadResult({
        success: false,
        message: 'Only Process Owners can upload data files'
      });
      return;
    }

    // Validate file type
    const validTypes = ['.csv', '.xlsx', '.xls'];
    const fileExtension = file.name.toLowerCase().substring(file.name.lastIndexOf('.'));
    
    if (!validTypes.includes(fileExtension)) {
      setUploadResult({
        success: false,
        message: 'Please upload a CSV or Excel file (.csv, .xlsx, .xls)'
      });
      return;
    }

    // Validate file size (50MB limit)
    if (file.size > 50 * 1024 * 1024) {
      setUploadResult({
        success: false,
        message: 'File size must be less than 50MB'
      });
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);
    setUploadResult(null);

    try {
      // Simulate file processing with progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 200);

      // Parse CSV file (simplified for demo)
      const text = await file.text();
      const lines = text.split('\n').filter(line => line.trim());
      
      if (lines.length < 2) {
        throw new Error('File must contain at least a header row and one data row');
      }

      // Extract headers
      const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
      
      // Validate minimum required columns
      const requiredColumns = ['User_ID', 'Access_Type', 'System', 'Status'];
      const missingColumns = requiredColumns.filter(col => !headers.includes(col));
      
      if (missingColumns.length > 0) {
        throw new Error(`Missing required columns: ${missingColumns.join(', ')}`);
      }

      // Parse data rows
      const records: AccessRecord[] = [];
      const batchId = `batch_${Date.now()}`;
      
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
        
        if (values.length !== headers.length) {
          console.warn(`Row ${i + 1} has ${values.length} columns, expected ${headers.length}`);
          continue;
        }

        const data: Record<string, string | number | boolean> = {};
        headers.forEach((header, index) => {
          let value: string | number | boolean = values[index] || '';
          
          // Try to parse numbers
          if (typeof value === 'string' && !isNaN(Number(value)) && value !== '') {
            value = Number(value);
          }
          
          // Parse booleans
          if (typeof value === 'string') {
            if (value.toLowerCase() === 'true') value = true;
            else if (value.toLowerCase() === 'false') value = false;
          }
          
          data[header] = value;
        });

        records.push({
          id: `record_${Date.now()}_${i}`,
          batchId,
          data,
          status: 'Pending',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
      }

      // Complete progress
      setUploadProgress(100);
      
      // Add records to context
      addAccessRecords(records);
      setColumns(headers);

      setUploadResult({
        success: true,
        message: 'File uploaded and processed successfully',
        recordsCount: records.length,
        columnsCount: headers.length
      });

    } catch (error) {
      setUploadResult({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to process file'
      });
    } finally {
      setIsUploading(false);
      setTimeout(() => setUploadProgress(0), 2000);
    }
  };

  const clearResult = () => {
    setUploadResult(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-16 2xl:px-24">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => navigate('/dashboard')}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
              <h1 className="text-2xl font-bold text-gray-900">Data Upload</h1>
            </div>
          </div>
        </div>
      </header>

      <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-16 2xl:px-24 py-8">
        {!canUpload && (
          <Alert className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Only Process Owners can upload data files. Contact your Process Owner to upload data.
            </AlertDescription>
          </Alert>
        )}

        {/* Upload Area */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Upload className="w-5 h-5 mr-2" />
              Upload Access Data
            </CardTitle>
            <CardDescription>
              Upload CSV or Excel files containing access certification data
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                isDragOver 
                  ? 'border-blue-400 bg-blue-50' 
                  : 'border-gray-300 hover:border-gray-400'
              } ${!canUpload ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => canUpload && fileInputRef.current?.click()}
            >
              <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                {isDragOver ? 'Drop your file here' : 'Upload your data file'}
              </h3>
              <p className="text-gray-600 mb-4">
                Drag and drop your CSV or Excel file, or click to browse
              </p>
              <div className="flex justify-center space-x-4 text-sm text-gray-500">
                <Badge variant="outline">.csv</Badge>
                <Badge variant="outline">.xlsx</Badge>
                <Badge variant="outline">.xls</Badge>
              </div>
              <p className="text-xs text-gray-400 mt-2">
                Maximum file size: 50MB
              </p>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.xlsx,.xls"
              onChange={handleFileSelect}
              className="hidden"
              disabled={!canUpload}
            />

            {isUploading && (
              <div className="mt-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Processing file...</span>
                  <span className="text-sm text-gray-600">{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} className="w-full" />
              </div>
            )}

            {uploadResult && (
              <Alert className={`mt-6 ${uploadResult.success ? 'border-green-200 bg-green-50' : ''}`}>
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-2">
                    {uploadResult.success ? (
                      <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                    ) : (
                      <AlertCircle className="h-4 w-4 text-red-600 mt-0.5" />
                    )}
                    <div>
                      <AlertDescription className={uploadResult.success ? 'text-green-800' : ''}>
                        {uploadResult.message}
                      </AlertDescription>
                      {uploadResult.success && uploadResult.recordsCount && (
                        <div className="mt-2 text-sm text-green-700">
                          <p>• {uploadResult.recordsCount} records processed</p>
                          <p>• {uploadResult.columnsCount} columns detected</p>
                        </div>
                      )}
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={clearResult}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* File Requirements */}
        <Card>
          <CardHeader>
            <CardTitle>File Requirements</CardTitle>
            <CardDescription>
              Ensure your file meets these requirements for successful upload
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-gray-900 mb-3">Required Columns</h4>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    User_ID
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Access_Type
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    System
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Status
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium text-gray-900 mb-3">File Specifications</h4>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    CSV, XLSX, or XLS format
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Maximum 50MB file size
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Header row required
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Up to 40 columns supported
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {uploadResult?.success && (
          <div className="mt-6 text-center">
            <Button onClick={() => navigate('/records')}>
              View Uploaded Records
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}