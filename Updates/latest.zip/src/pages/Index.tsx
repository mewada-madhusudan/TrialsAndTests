import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Users, FileText, BarChart3 } from 'lucide-react';

export default function Index() {
  const [sid, setSid] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  // Redirect if already authenticated
  if (isAuthenticated) {
    navigate('/dashboard');
    return null;
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const success = await login(sid, password);
      if (success) {
        navigate('/dashboard');
      } else {
        setError('Invalid SID or password. Try: PO001, AO001, AO002, C001, or C002 with password "demo123"');
      }
    } catch (err) {
      setError('Login failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        {/* Left side - Branding and Features */}
        <div className="space-y-8">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              Access<span className="text-blue-600">Gate</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Streamline your access certification management with powerful delegation, 
              data upload, and reporting capabilities.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="flex items-start space-x-3">
              <Shield className="w-8 h-8 text-blue-600 mt-1" />
              <div>
                <h3 className="font-semibold text-gray-900">Role-Based Access</h3>
                <p className="text-sm text-gray-600">Process Owners, Area Owners, and Certifiers</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Users className="w-8 h-8 text-green-600 mt-1" />
              <div>
                <h3 className="font-semibold text-gray-900">Delegation Management</h3>
                <p className="text-sm text-gray-600">Assign and track delegation workflows</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <FileText className="w-8 h-8 text-orange-600 mt-1" />
              <div>
                <h3 className="font-semibold text-gray-900">Data Upload</h3>
                <p className="text-sm text-gray-600">Excel/CSV support with dynamic columns</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <BarChart3 className="w-8 h-8 text-purple-600 mt-1" />
              <div>
                <h3 className="font-semibold text-gray-900">Advanced Reporting</h3>
                <p className="text-sm text-gray-600">Comprehensive analytics and exports</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right side - Login Form */}
        <div className="flex justify-center lg:justify-end">
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Sign In</CardTitle>
              <CardDescription>
                Enter your SID and password to access AccessGate
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="sid">SID</Label>
                  <Input
                    id="sid"
                    type="text"
                    placeholder="Enter your SID"
                    value={sid}
                    onChange={(e) => setSid(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>
                
                {error && (
                  <Alert variant="destructive">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Signing in...' : 'Sign In'}
                </Button>
              </form>

              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <p className="text-sm font-medium text-blue-900 mb-2">Demo Accounts:</p>
                <div className="text-xs text-blue-800 space-y-1">
                  <div>Process Owner: <code className="bg-blue-100 px-1 rounded">PO001</code></div>
                  <div>Area Owner: <code className="bg-blue-100 px-1 rounded">AO001, AO002</code></div>
                  <div>Certifier: <code className="bg-blue-100 px-1 rounded">C001, C002</code></div>
                  <div>Password: <code className="bg-blue-100 px-1 rounded">demo123</code></div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}