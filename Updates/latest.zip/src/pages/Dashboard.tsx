import { useAuth } from '@/contexts/AuthContext';
import { useData } from '@/contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { 
  Users, 
  FileText, 
  CheckCircle, 
  Clock, 
  XCircle, 
  AlertCircle,
  Upload,
  UserCheck,
  Database,
  LogOut
} from 'lucide-react';

export default function Dashboard() {
  const { user, logout } = useAuth();
  const { getStatusSummary, accessRecords, delegations } = useData();
  const navigate = useNavigate();
  
  const statusSummary = getStatusSummary();
  const totalRecords = accessRecords.length;
  const pendingDelegations = delegations.filter(d => d.status === 'Pending').length;

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const roleColor = {
    'Process Owner': 'bg-purple-100 text-purple-800',
    'Area Owner': 'bg-blue-100 text-blue-800',
    'Certifier': 'bg-green-100 text-green-800'
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-16 2xl:px-24">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-gray-900">
                Access<span className="text-blue-600">Gate</span>
              </h1>
              <Badge className={roleColor[user?.role || 'Certifier']}>
                {user?.role}
              </Badge>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">
                Welcome, <span className="font-medium">{user?.name}</span>
              </span>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-16 2xl:px-24 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h2>
          <p className="text-gray-600">
            Manage access certifications, delegations, and generate reports
          </p>
        </div>

        {/* Status Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 2xl:grid-cols-6 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Reviews</CardTitle>
              <Clock className="h-4 w-4 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{statusSummary.pending}</div>
              <p className="text-xs text-muted-foreground">
                Awaiting certification
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">In Review</CardTitle>
              <AlertCircle className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{statusSummary.inReview}</div>
              <p className="text-xs text-muted-foreground">
                Currently being reviewed
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Certified</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{statusSummary.certified}</div>
              <p className="text-xs text-muted-foreground">
                Successfully certified
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Rejected</CardTitle>
              <XCircle className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{statusSummary.rejected}</div>
              <p className="text-xs text-muted-foreground">
                Rejected records
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Database className="w-5 h-5 mr-2" />
                Quick Actions
              </CardTitle>
              <CardDescription>
                Common tasks for your role
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {(user?.role === 'Process Owner' || user?.role === 'Area Owner') && (
                <>
                  <Button 
                    className="w-full justify-start" 
                    variant="outline"
                    onClick={() => navigate('/upload')}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Data File
                  </Button>
                  <Button 
                    className="w-full justify-start" 
                    variant="outline"
                    onClick={() => navigate('/delegations')}
                  >
                    <UserCheck className="w-4 h-4 mr-2" />
                    Manage Delegations
                  </Button>
                </>
              )}
              <Button 
                className="w-full justify-start" 
                variant="outline"
                onClick={() => navigate('/records')}
              >
                <FileText className="w-4 h-4 mr-2" />
                Review Records
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="w-5 h-5 mr-2" />
                System Overview
              </CardTitle>
              <CardDescription>
                Current system statistics
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Total Records</span>
                <span className="font-semibold">{totalRecords}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Pending Delegations</span>
                <span className="font-semibold">{pendingDelegations}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Completion Rate</span>
                <span className="font-semibold">
                  {totalRecords > 0 
                    ? Math.round(((statusSummary.certified + statusSummary.rejected) / totalRecords) * 100)
                    : 0
                  }%
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        {totalRecords > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>
                Latest updates to access records
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {accessRecords.slice(0, 5).map((record) => (
                  <div key={record.id} className="flex items-center justify-between py-2 border-b last:border-b-0">
                    <div className="flex items-center space-x-3">
                      <div className={`w-2 h-2 rounded-full ${
                        record.status === 'Certified' ? 'bg-green-500' :
                        record.status === 'Rejected' ? 'bg-red-500' :
                        record.status === 'In Review' ? 'bg-blue-500' : 'bg-orange-500'
                      }`} />
                      <div>
                        <p className="text-sm font-medium">
                          Record {record.id.slice(0, 8)}...
                        </p>
                        <p className="text-xs text-gray-500">
                          {new Date(record.updatedAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <Badge variant={
                      record.status === 'Certified' ? 'default' :
                      record.status === 'Rejected' ? 'destructive' :
                      record.status === 'In Review' ? 'secondary' : 'outline'
                    }>
                      {record.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}