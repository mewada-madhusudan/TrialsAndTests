import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface User {
  id: string;
  sid: string;
  name: string;
  role: 'Process Owner' | 'Area Owner' | 'Certifier';
}

interface AuthContextType {
  user: User | null;
  login: (sid: string, password: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users for demo
const mockUsers: User[] = [
  { id: '1', sid: 'PO001', name: 'John Smith', role: 'Process Owner' },
  { id: '2', sid: 'AO001', name: 'Sarah Johnson', role: 'Area Owner' },
  { id: '3', sid: 'AO002', name: 'Mike Davis', role: 'Area Owner' },
  { id: '4', sid: 'C001', name: 'Emily Brown', role: 'Certifier' },
  { id: '5', sid: 'C002', name: 'David Wilson', role: 'Certifier' },
];

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem('accessgate_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const login = async (sid: string, password: string): Promise<boolean> => {
    // Mock authentication - in real app, this would call an API
    const foundUser = mockUsers.find(u => u.sid === sid);
    if (foundUser && password === 'demo123') {
      setUser(foundUser);
      localStorage.setItem('accessgate_user', JSON.stringify(foundUser));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('accessgate_user');
  };

  return (
    <AuthContext.Provider value={{
      user,
      login,
      logout,
      isAuthenticated: !!user
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};