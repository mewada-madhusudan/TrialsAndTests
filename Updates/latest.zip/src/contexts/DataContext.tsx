import React, { createContext, useContext, useState, ReactNode } from 'react';
import { useAuth } from './AuthContext';

export interface AccessRecord {
  id: string;
  batchId: string;
  data: Record<string, string | number | boolean>;
  status: 'Pending' | 'In Review' | 'Certified' | 'Rejected' | 'Open for Review' | 'Access Required';
  certifierId?: string;
  areaOwnerSid?: string; // NEW: For filtering
  comments?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Delegation {
  id: string;
  areaOwnerId: string;
  delegateId: string;
  delegateName: string;
  status: 'Pending' | 'Accepted' | 'Rejected';
  createdAt: string;
}

interface DataContextType {
  accessRecords: AccessRecord[];
  filteredRecords: AccessRecord[]; // NEW: Filtered records based on user role
  delegations: Delegation[];
  columns: string[];
  addAccessRecords: (records: AccessRecord[]) => void;
  updateAccessRecord: (id: string, updates: Partial<AccessRecord>) => void;
  updateMultipleRecords: (updates: { id: string; updates: Partial<AccessRecord> }[]) => void; // NEW: Batch updates
  addDelegation: (delegation: Omit<Delegation, 'id' | 'createdAt'>) => void;
  updateDelegation: (id: string, status: 'Accepted' | 'Rejected') => void;
  setColumns: (columns: string[]) => void;
  getStatusSummary: () => { 
    pending: number; 
    inReview: number; 
    certified: number; 
    rejected: number;
    openForReview: number; // NEW
    accessRequired: number; // NEW
  };
  getDynamicColumns: () => string[]; // NEW: Get all columns from data
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [accessRecords, setAccessRecords] = useState<AccessRecord[]>([]);
  const [delegations, setDelegations] = useState<Delegation[]>([]);
  const [columns, setColumns] = useState<string[]>([]);

  // Get filtered records based on user role and SID
  const getFilteredRecords = (userRole?: string, userSid?: string): AccessRecord[] => {
    if (!userRole || !userSid) return accessRecords;

    switch (userRole) {
      case 'Process Owner':
        return accessRecords; // See all records
      
      case 'Area Owner':
        return accessRecords.filter(record => {
          // Check both the data column and the areaOwnerSid field
          const areaOwnerSidFromData = record.data['Area Owner SID'] || record.data['area_owner_sid'] || record.data['AreaOwnerSID'];
          return areaOwnerSidFromData === userSid || record.areaOwnerSid === userSid;
        });
      
      case 'Certifier':
        return accessRecords.filter(record => 
          record.certifierId === userSid || 
          record.data['Certifier SID'] === userSid ||
          record.data['certifier_sid'] === userSid
        );
      
      default:
        return [];
    }
  };

  const addAccessRecords = (records: AccessRecord[]) => {
    // Extract Area Owner SID from data and set it in the record
    const processedRecords = records.map(record => ({
      ...record,
      areaOwnerSid: record.data['Area Owner SID'] || record.data['area_owner_sid'] || record.data['AreaOwnerSID'] as string
    }));
    setAccessRecords(prev => [...prev, ...processedRecords]);
  };

  const updateAccessRecord = (id: string, updates: Partial<AccessRecord>) => {
    setAccessRecords(prev => 
      prev.map(record => 
        record.id === id 
          ? { ...record, ...updates, updatedAt: new Date().toISOString() }
          : record
      )
    );
  };

  // NEW: Batch update multiple records
  const updateMultipleRecords = (updates: { id: string; updates: Partial<AccessRecord> }[]) => {
    setAccessRecords(prev => 
      prev.map(record => {
        const update = updates.find(u => u.id === record.id);
        return update 
          ? { ...record, ...update.updates, updatedAt: new Date().toISOString() }
          : record;
      })
    );
  };

  const addDelegation = (delegation: Omit<Delegation, 'id' | 'createdAt'>) => {
    const newDelegation: Delegation = {
      ...delegation,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toISOString()
    };
    setDelegations(prev => [...prev, newDelegation]);
  };

  const updateDelegation = (id: string, status: 'Accepted' | 'Rejected') => {
    setDelegations(prev =>
      prev.map(delegation =>
        delegation.id === id ? { ...delegation, status } : delegation
      )
    );
  };

  const getStatusSummary = () => {
    return accessRecords.reduce(
      (acc, record) => {
        switch (record.status) {
          case 'Pending':
            acc.pending++;
            break;
          case 'In Review':
            acc.inReview++;
            break;
          case 'Certified':
            acc.certified++;
            break;
          case 'Rejected':
            acc.rejected++;
            break;
          case 'Open for Review':
            acc.openForReview++;
            break;
          case 'Access Required':
            acc.accessRequired++;
            break;
        }
        return acc;
      },
      { pending: 0, inReview: 0, certified: 0, rejected: 0, openForReview: 0, accessRequired: 0 }
    );
  };

  // NEW: Get all dynamic columns from uploaded data
  const getDynamicColumns = (): string[] => {
    if (accessRecords.length === 0) return [];
    
    const allColumns = new Set<string>();
    accessRecords.forEach(record => {
      Object.keys(record.data).forEach(key => allColumns.add(key));
    });
    
    return Array.from(allColumns).sort();
  };

  return (
    <DataContext.Provider value={{
      accessRecords,
      filteredRecords: [], // Will be computed in component using useAuth
      delegations,
      columns,
      addAccessRecords,
      updateAccessRecord,
      updateMultipleRecords,
      addDelegation,
      updateDelegation,
      setColumns,
      getStatusSummary,
      getDynamicColumns
    }}>
      {children}
    </DataContext.Provider>
  );
};

// Custom hook that includes filtering logic
export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

// Custom hook that returns filtered records based on current user
export const useFilteredData = () => {
  const context = useData();
  const { user } = useAuth();
  
  const getFilteredRecords = (): AccessRecord[] => {
    if (!user) return [];
    
    switch (user.role) {
      case 'Process Owner':
        return context.accessRecords; // See all records
      
      case 'Area Owner':
        return context.accessRecords.filter(record => {
          const areaOwnerSidFromData = record.data['Area Owner SID'] || 
                                     record.data['area_owner_sid'] || 
                                     record.data['AreaOwnerSID'];
          return areaOwnerSidFromData === user.sid || record.areaOwnerSid === user.sid;
        });
      
      case 'Certifier':
        return context.accessRecords.filter(record => 
          record.certifierId === user.sid || 
          record.data['Certifier SID'] === user.sid ||
          record.data['certifier_sid'] === user.sid
        );
      
      default:
        return [];
    }
  };

  return {
    ...context,
    filteredRecords: getFilteredRecords()
  };
};