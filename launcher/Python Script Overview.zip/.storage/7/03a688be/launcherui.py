import getpass
import os
import sys
import time
import threading
from datetime import timedelta, datetime

import pandas as pd
import urllib3
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QPropertyAnimation, QRect, QEasingCurve
from PyQt6.QtGui import QIcon, QPixmap, QPainter, QColor, QFont, QPen, QMovie
from PyQt6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout, 
                             QLabel, QFrame, QScrollArea, QGridLayout, QPushButton,
                             QMessageBox, QDialog, QProgressBar, QStackedWidget)

from access import AccessControlDialog
from security_check import LauncherSecurity
from static import (resource_path, SID, SITE_URL, BACKUP_PATH, SHAREPOINT_LIST, 
                   BACKUP_FILE_NAME, LABEL_TEXT, USERBASE, user_main, COST_CENTER,
                   expire_sort, split_user, UAT, PROD, BETA, LOB, pslv_action_entry)

# Suppress ssl warnings for sharepoint api calls
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class LoadingOverlay(QWidget):
    """Loading overlay widget with animated elements"""
    
    def __init__(self, parent=None, animation_type="spinner"):
        super().__init__(parent)
        self.animation_type = animation_type
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setStyleSheet("background-color: rgba(0, 0, 0, 0.7);")
        
        self.setup_ui()
        self.setup_animation()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Container for loading content
        container = QFrame()
        container.setFixedSize(200, 120)
        container.setStyleSheet("""
            QFrame {
                background-color: rgba(255, 255, 255, 0.95);
                border-radius: 10px;
                border: 1px solid rgba(0, 0, 0, 0.1);
            }
        """)
        
        container_layout = QVBoxLayout(container)
        container_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        container_layout.setSpacing(15)
        
        # Animation widget
        self.animation_widget = QLabel()
        self.animation_widget.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.animation_widget.setFixedSize(60, 60)
        
        # Loading text
        self.loading_label = QLabel("Launching...")
        self.loading_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.loading_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 14px;
                font-weight: 500;
                font-family: 'Segoe UI', Arial, sans-serif;
            }
        """)
        
        container_layout.addWidget(self.animation_widget)
        container_layout.addWidget(self.loading_label)
        layout.addWidget(container)
        
    def setup_animation(self):
        if self.animation_type == "rabbit":
            self.setup_rabbit_animation()
        elif self.animation_type == "turtle":
            self.setup_turtle_animation()
        else:
            self.setup_spinner_animation()
            
    def setup_spinner_animation(self):
        """Setup spinning circle animation"""
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_spinner)
        self.angle = 0
        self.timer.start(50)  # Update every 50ms
        
    def setup_rabbit_animation(self):
        """Setup running rabbit animation"""
        self.loading_label.setText("🐰 Starting application...")
        self.animation_widget.setText("🐰")
        self.animation_widget.setStyleSheet("font-size: 40px;")
        
        # Bouncing animation
        self.bounce_timer = QTimer()
        self.bounce_timer.timeout.connect(self.bounce_rabbit)
        self.bounce_direction = 1
        self.bounce_timer.start(300)
        
    def setup_turtle_animation(self):
        """Setup turtle animation"""
        self.loading_label.setText("🐢 Loading slowly but surely...")
        self.animation_widget.setText("🐢")
        self.animation_widget.setStyleSheet("font-size: 40px;")
        
        # Slow rotation
        self.turtle_timer = QTimer()
        self.turtle_timer.timeout.connect(self.rotate_turtle)
        self.turtle_angle = 0
        self.turtle_timer.start(800)  # Slower animation
        
    def update_spinner(self):
        """Update spinner animation"""
        self.angle = (self.angle + 10) % 360
        pixmap = QPixmap(60, 60)
        pixmap.fill(Qt.GlobalColor.transparent)
        
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Draw spinning circle
        pen = QPen(QColor(25, 118, 210), 4)
        painter.setPen(pen)
        painter.drawArc(10, 10, 40, 40, self.angle * 16, 120 * 16)
        
        painter.end()
        self.animation_widget.setPixmap(pixmap)
        
    def bounce_rabbit(self):
        """Animate bouncing rabbit"""
        current_size = self.animation_widget.font().pointSize()
        if current_size >= 45:
            self.bounce_direction = -1
        elif current_size <= 35:
            self.bounce_direction = 1
            
        new_size = current_size + (self.bounce_direction * 2)
        self.animation_widget.setStyleSheet(f"font-size: {new_size}px;")
        
    def rotate_turtle(self):
        """Animate rotating turtle"""
        emojis = ["🐢", "🐢", "🐢", "🐢"]  # Could add different orientations
        self.turtle_angle = (self.turtle_angle + 1) % len(emojis)
        
    def resizeEvent(self, event):
        """Ensure overlay covers the entire parent"""
        if self.parent():
            self.resize(self.parent().size())
        super().resizeEvent(event)
        
    def showEvent(self, event):
        """Start animations when shown"""
        super().showEvent(event)
        if hasattr(self, 'timer'):
            self.timer.start()
        if hasattr(self, 'bounce_timer'):
            self.bounce_timer.start()
        if hasattr(self, 'turtle_timer'):
            self.turtle_timer.start()
            
    def hideEvent(self, event):
        """Stop animations when hidden"""
        super().hideEvent(event)
        if hasattr(self, 'timer'):
            self.timer.stop()
        if hasattr(self, 'bounce_timer'):
            self.bounce_timer.stop()
        if hasattr(self, 'turtle_timer'):
            self.turtle_timer.stop()


class ApplicationLauncher(QThread):
    """Thread for launching applications to prevent UI blocking"""
    
    launch_completed = pyqtSignal()
    launch_failed = pyqtSignal(str)
    
    def __init__(self, app_path, app_name):
        super().__init__()
        self.app_path = app_path
        self.app_name = app_name
        
    def run(self):
        """Launch the application in a separate thread"""
        try:
            # Generate security token if needed
            token = LauncherSecurity.generate_launch_token(self.app_path)
            if token is None:
                self.launch_failed.emit("Security token generation failed")
                return
                
            # Log the launch action
            pslv_action_entry([{
                'SID': user_main, 
                'action': f'Launched application: {self.app_name}'
            }])
            
            # Launch the application
            os.startfile(self.app_path)
            
            # Wait a bit to ensure the application starts
            time.sleep(2)
            
            self.launch_completed.emit()
            
        except Exception as e:
            self.launch_failed.emit(f"Failed to launch {self.app_name}: {str(e)}")


class ApplicationTile(QFrame):
    """Enhanced Application tile with loading overlay support"""
    
    def __init__(self, app_data, parent=None):
        super().__init__(parent)
        self.app_data = app_data
        self.loading_overlay = None
        self.launcher_thread = None
        
        self.setFixedSize(280, 180)
        self.setFrameStyle(QFrame.Shape.StyledPanel)
        self.setup_ui()
        self.setup_styles()
        
    def setup_ui(self):
        """Setup the tile UI components"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)
        
        # App icon (placeholder)
        icon_label = QLabel("📱")
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_label.setStyleSheet("font-size: 32px;")
        layout.addWidget(icon_label)
        
        # App name
        name_label = QLabel(self.app_data.get('Solution_Name', 'Unknown App'))
        name_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        name_label.setWordWrap(True)
        name_label.setStyleSheet("""
            QLabel {
                font-size: 14px;
                font-weight: bold;
                color: #1976d2;
                margin: 5px 0px;
            }
        """)
        layout.addWidget(name_label)
        
        # App description
        desc_text = self.app_data.get('Description', 'No description available')
        if len(desc_text) > 80:
            desc_text = desc_text[:77] + "..."
            
        desc_label = QLabel(desc_text)
        desc_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        desc_label.setWordWrap(True)
        desc_label.setStyleSheet("""
            QLabel {
                font-size: 11px;
                color: #666;
                margin: 5px 0px;
            }
        """)
        layout.addWidget(desc_label)
        
        # Launch button
        self.launch_button = QPushButton("Launch")
        self.launch_button.clicked.connect(self.launch_application)
        self.launch_button.setStyleSheet("""
            QPushButton {
                background-color: #1976d2;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 6px;
                font-weight: 500;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #1565c0;
            }
            QPushButton:pressed {
                background-color: #0d47a1;
            }
            QPushButton:disabled {
                background-color: #ccc;
                color: #999;
            }
        """)
        layout.addWidget(self.launch_button)
        
        # Version and status info
        version = self.app_data.get('Version_Number', 'N/A')
        status = self.app_data.get('Status', 'Unknown')
        info_label = QLabel(f"v{version} • {status}")
        info_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info_label.setStyleSheet("""
            QLabel {
                font-size: 10px;
                color: #999;
                margin-top: 5px;
            }
        """)
        layout.addWidget(info_label)
        
    def setup_styles(self):
        """Setup tile styling based on app status"""
        status = self.app_data.get('Status', '').upper()
        
        if status == 'PROD':
            border_color = PROD
        elif status == 'UAT':
            border_color = UAT
        elif status == 'BETA':
            border_color = BETA
        else:
            border_color = '#e0e0e0'
            
        self.setStyleSheet(f"""
            ApplicationTile {{
                background-color: white;
                border: 2px solid {border_color};
                border-radius: 10px;
                margin: 5px;
            }}
            ApplicationTile:hover {{
                background-color: #f8f9fa;
                border-color: #1976d2;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }}
        """)
        
    def launch_application(self):
        """Launch the application with loading overlay"""
        app_path = self.app_data.get('ApplicationExePath', '')
        app_name = self.app_data.get('Solution_Name', 'Unknown App')
        
        if not app_path or not os.path.exists(app_path):
            QMessageBox.warning(
                self, 
                "Application Not Found", 
                f"The application '{app_name}' could not be found at:\n{app_path}"
            )
            return
            
        # Disable launch button
        self.launch_button.setEnabled(False)
        self.launch_button.setText("Launching...")
        
        # Show loading overlay with random animation type
        animation_types = ["spinner", "rabbit", "turtle"]
        import random
        animation_type = random.choice(animation_types)
        
        self.show_loading_overlay(animation_type)
        
        # Start launcher thread
        self.launcher_thread = ApplicationLauncher(app_path, app_name)
        self.launcher_thread.launch_completed.connect(self.on_launch_completed)
        self.launcher_thread.launch_failed.connect(self.on_launch_failed)
        self.launcher_thread.start()
        
        # Set a maximum timeout for the loading overlay
        QTimer.singleShot(10000, self.hide_loading_overlay)  # 10 second timeout
        
    def show_loading_overlay(self, animation_type="spinner"):
        """Show the loading overlay with specified animation"""
        if self.loading_overlay is None:
            self.loading_overlay = LoadingOverlay(self, animation_type)
            
        self.loading_overlay.resize(self.size())
        self.loading_overlay.show()
        self.loading_overlay.raise_()
        
    def hide_loading_overlay(self):
        """Hide the loading overlay"""
        if self.loading_overlay:
            self.loading_overlay.hide()
            
        # Re-enable launch button
        self.launch_button.setEnabled(True)
        self.launch_button.setText("Launch")
        
    def on_launch_completed(self):
        """Handle successful application launch"""
        self.hide_loading_overlay()
        
        # Optional: Show brief success indication
        self.launch_button.setText("Launched!")
        self.launch_button.setStyleSheet("""
            QPushButton {
                background-color: #4caf50;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 6px;
                font-weight: 500;
                font-size: 12px;
            }
        """)
        
        # Reset button after 2 seconds
        QTimer.singleShot(2000, self.reset_launch_button)
        
    def on_launch_failed(self, error_message):
        """Handle failed application launch"""
        self.hide_loading_overlay()
        
        QMessageBox.critical(
            self,
            "Launch Failed",
            error_message
        )
        
        # Reset button
        self.reset_launch_button()
        
    def reset_launch_button(self):
        """Reset launch button to original state"""
        self.launch_button.setEnabled(True)
        self.launch_button.setText("Launch")
        self.launch_button.setStyleSheet("""
            QPushButton {
                background-color: #1976d2;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 6px;
                font-weight: 500;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #1565c0;
            }
            QPushButton:pressed {
                background-color: #0d47a1;
            }
        """)
        
    def resizeEvent(self, event):
        """Ensure loading overlay resizes with tile"""
        super().resizeEvent(event)
        if self.loading_overlay:
            self.loading_overlay.resize(self.size())


class MainWindow(QWidget):
    """Main application window"""
    
    def __init__(self, data, cost_centers=None, user_data=None):
        super().__init__()
        self.data = data
        self.cost_centers = cost_centers if cost_centers is not None else pd.DataFrame()
        self.user_data = user_data if user_data is not None else pd.DataFrame()
        
        self.setWindowTitle('PSLV Application Launcher')
        self.setWindowIcon(QIcon(resource_path("resources/STOJustLogo.PNG")))
        self.setMinimumSize(1200, 800)
        
        self.setup_ui()
        self.load_applications()
        
    def setup_ui(self):
        """Setup the main window UI"""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(20)
        
        # Header
        header_layout = QHBoxLayout()
        
        title_label = QLabel("Application Launcher")
        title_label.setStyleSheet("""
            QLabel {
                font-size: 24px;
                font-weight: bold;
                color: #1976d2;
                margin-bottom: 10px;
            }
        """)
        header_layout.addWidget(title_label)
        
        header_layout.addStretch()
        
        # Access control button
        access_btn = QPushButton("Manage Access")
        access_btn.clicked.connect(self.open_access_control)
        access_btn.setStyleSheet("""
            QPushButton {
                background-color: #f5f5f5;
                color: #333;
                border: 1px solid #ddd;
                padding: 10px 20px;
                border-radius: 6px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #e0e0e0;
            }
        """)
        header_layout.addWidget(access_btn)
        
        main_layout.addLayout(header_layout)
        
        # Applications scroll area
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #f8f9fa;
            }
        """)
        
        self.apps_widget = QWidget()
        self.apps_layout = QGridLayout(self.apps_widget)
        self.apps_layout.setSpacing(15)
        self.apps_layout.setContentsMargins(20, 20, 20, 20)
        
        scroll_area.setWidget(self.apps_widget)
        main_layout.addWidget(scroll_area)
        
        # Footer
        footer_label = QLabel(LABEL_TEXT)
        footer_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        footer_label.setStyleSheet("""
            QLabel {
                color: #666;
                font-size: 12px;
                margin-top: 10px;
            }
        """)
        main_layout.addWidget(footer_label)
        
    def load_applications(self):
        """Load and display application tiles"""
        if self.data.empty:
            no_apps_label = QLabel("No applications available")
            no_apps_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            no_apps_label.setStyleSheet("""
                QLabel {
                    color: #999;
                    font-size: 16px;
                    margin: 50px;
                }
            """)
            self.apps_layout.addWidget(no_apps_label, 0, 0)
            return
            
        # Filter out expired applications
        current_data = self.data.copy()
        current_data['Expired'] = current_data.apply(expire_sort, axis=1)
        active_apps = current_data[~current_data['Expired']]
        
        # Create tiles
        row, col = 0, 0
        max_cols = 4
        
        for _, app_data in active_apps.iterrows():
            tile = ApplicationTile(app_data.to_dict())
            self.apps_layout.addWidget(tile, row, col)
            
            col += 1
            if col >= max_cols:
                col = 0
                row += 1
                
        # Add stretch to push tiles to top-left
        self.apps_layout.setRowStretch(row + 1, 1)
        self.apps_layout.setColumnStretch(max_cols, 1)
        
    def open_access_control(self):
        """Open access control dialog"""
        try:
            if not self.user_data.empty:
                user_lob = self.user_data.iloc[0].get('cost_center_id', '')
                lob_list = [user_lob] if user_lob else LOB
            else:
                lob_list = LOB
                
            dialog = AccessControlDialog(user_main, lob_list, self)
            dialog.exec()
        except Exception as e:
            QMessageBox.warning(
                self,
                "Access Control Error",
                f"Failed to open access control: {str(e)}"
            )


if __name__ == '__main__':
    app = QApplication(sys.argv)
    
    # Sample data for testing
    sample_data = pd.DataFrame([
        {
            'Solution_Name': 'Test Application',
            'Description': 'A sample application for testing the loading overlay functionality',
            'ApplicationExePath': 'C:\\Windows\\System32\\notepad.exe',
            'Version_Number': '1.0',
            'Status': 'PROD',
            'Release_Date': '2024-01-01',
            'Validity_Period': 365
        }
    ])
    
    window = MainWindow(sample_data)
    window.show()
    
    sys.exit(app.exec())