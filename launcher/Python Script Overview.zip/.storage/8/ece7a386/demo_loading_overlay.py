"""
Demo script to showcase the loading overlay functionality
This can be run independently to test the loading overlay without the full application
"""

import sys
import time
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel
from PyQt6.QtCore import QTimer, Qt

# Import the LoadingOverlay from the modified launcherui
try:
    from launcherui import LoadingOverlay
except ImportError:
    print("Please ensure launcherui.py is in the same directory")
    sys.exit(1)


class LoadingDemo(QWidget):
    """Demo widget to test loading overlays"""
    
    def __init__(self):
        super().__init__()
        self.loading_overlay = None
        self.setup_ui()
        
    def setup_ui(self):
        self.setWindowTitle("Loading Overlay Demo")
        self.setFixedSize(400, 300)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(20)
        layout.setContentsMargins(50, 50, 50, 50)
        
        # Title
        title = QLabel("Loading Overlay Demo")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("""
            QLabel {
                font-size: 18px;
                font-weight: bold;
                color: #333;
                margin-bottom: 20px;
            }
        """)
        layout.addWidget(title)
        
        # Demo buttons
        spinner_btn = QPushButton("Show Spinner Loading")
        spinner_btn.clicked.connect(lambda: self.show_loading("spinner"))
        layout.addWidget(spinner_btn)
        
        rabbit_btn = QPushButton("Show Rabbit Loading")
        rabbit_btn.clicked.connect(lambda: self.show_loading("rabbit"))
        layout.addWidget(rabbit_btn)
        
        turtle_btn = QPushButton("Show Turtle Loading")
        turtle_btn.clicked.connect(lambda: self.show_loading("turtle"))
        layout.addWidget(turtle_btn)
        
        # Style buttons
        button_style = """
            QPushButton {
                background-color: #1976d2;
                color: white;
                border: none;
                padding: 12px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #1565c0;
            }
            QPushButton:pressed {
                background-color: #0d47a1;
            }
        """
        
        for button in [spinner_btn, rabbit_btn, turtle_btn]:
            button.setStyleSheet(button_style)
            
    def show_loading(self, animation_type):
        """Show loading overlay with specified animation type"""
        if self.loading_overlay:
            self.loading_overlay.hide()
            
        self.loading_overlay = LoadingOverlay(self, animation_type)
        self.loading_overlay.resize(self.size())
        self.loading_overlay.show()
        self.loading_overlay.raise_()
        
        # Hide after 3 seconds for demo purposes
        QTimer.singleShot(3000, self.hide_loading)
        
    def hide_loading(self):
        """Hide the loading overlay"""
        if self.loading_overlay:
            self.loading_overlay.hide()
            
    def resizeEvent(self, event):
        """Ensure loading overlay resizes with window"""
        super().resizeEvent(event)
        if self.loading_overlay:
            self.loading_overlay.resize(self.size())


if __name__ == '__main__':
    app = QApplication(sys.argv)
    
    demo = LoadingDemo()
    demo.show()
    
    sys.exit(app.exec())